/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/clientPortalAccessCatalogue.ts" enhancement="_blank"/>
export const qryListClientPortalAccessRoute = 'buildFlowFsm.clientPortalAccessCatalogue.qryListClientPortalAccess';
export const cmdCreateClientPortalAccessRoute = 'buildFlowFsm.clientPortalAccessCatalogue.cmdCreateClientPortalAccess';
export const cmdUpdateClientPortalAccessRoute = 'buildFlowFsm.clientPortalAccessCatalogue.cmdUpdateClientPortalAccess';
export const cmdDeleteClientPortalAccessRoute = 'buildFlowFsm.clientPortalAccessCatalogue.cmdDeleteClientPortalAccess';
export const qryClientPickerRoute = 'buildFlowFsm.clientPortalAccessCatalogue.qryClientPicker';
