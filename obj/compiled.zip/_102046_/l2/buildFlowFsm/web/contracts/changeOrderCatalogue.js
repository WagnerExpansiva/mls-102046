/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/changeOrderCatalogue.ts" enhancement="_blank"/>
export const qryListChangeOrderRoute = 'buildFlowFsm.changeOrderCatalogue.qryListChangeOrder';
export const cmdCreateChangeOrderRoute = 'buildFlowFsm.changeOrderCatalogue.cmdCreateChangeOrder';
export const cmdUpdateChangeOrderRoute = 'buildFlowFsm.changeOrderCatalogue.cmdUpdateChangeOrder';
export const cmdDeleteChangeOrderRoute = 'buildFlowFsm.changeOrderCatalogue.cmdDeleteChangeOrder';
export const qryClientPickerRoute = 'buildFlowFsm.changeOrderCatalogue.qryClientPicker';
export const qryProjectPickerRoute = 'buildFlowFsm.changeOrderCatalogue.qryProjectPicker';
