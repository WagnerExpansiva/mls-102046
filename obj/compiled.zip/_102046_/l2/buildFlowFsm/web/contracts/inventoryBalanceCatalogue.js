/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/inventoryBalanceCatalogue.ts" enhancement="_blank"/>
export const qryListInventoryBalanceRoute = 'buildFlowFsm.inventoryBalanceCatalogue.qryListInventoryBalance';
export const cmdCreateInventoryBalanceRoute = 'buildFlowFsm.inventoryBalanceCatalogue.cmdCreateInventoryBalance';
export const cmdUpdateInventoryBalanceRoute = 'buildFlowFsm.inventoryBalanceCatalogue.cmdUpdateInventoryBalance';
export const cmdDeleteInventoryBalanceRoute = 'buildFlowFsm.inventoryBalanceCatalogue.cmdDeleteInventoryBalance';
export const qryInventoryItemPickerRoute = 'buildFlowFsm.inventoryBalanceCatalogue.qryInventoryItemPicker';
