/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/timeLogCatalogue.ts" enhancement="_blank"/>
export const qryListTimeLogRoute = 'buildFlowFsm.timeLogCatalogue.qryListTimeLog';
export const cmdCreateTimeLogRoute = 'buildFlowFsm.timeLogCatalogue.cmdCreateTimeLog';
export const cmdUpdateTimeLogRoute = 'buildFlowFsm.timeLogCatalogue.cmdUpdateTimeLog';
export const cmdDeleteTimeLogRoute = 'buildFlowFsm.timeLogCatalogue.cmdDeleteTimeLog';
export const qryWorkTaskPickerRoute = 'buildFlowFsm.timeLogCatalogue.qryWorkTaskPicker';
