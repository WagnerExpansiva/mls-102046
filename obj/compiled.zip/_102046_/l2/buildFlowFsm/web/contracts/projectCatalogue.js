/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/projectCatalogue.ts" enhancement="_blank"/>
export const qryListProjectRoute = 'buildFlowFsm.projectCatalogue.qryListProject';
export const cmdCreateProjectRoute = 'buildFlowFsm.projectCatalogue.cmdCreateProject';
export const cmdUpdateProjectRoute = 'buildFlowFsm.projectCatalogue.cmdUpdateProject';
export const cmdDeleteProjectRoute = 'buildFlowFsm.projectCatalogue.cmdDeleteProject';
export const qryClientPickerRoute = 'buildFlowFsm.projectCatalogue.qryClientPicker';
