/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/projectExecutionOverviewView.ts" enhancement="_blank"/>
export const qryProjectExecutionOverviewViewRoute = 'buildFlowFsm.projectExecutionOverviewView.qryProjectExecutionOverviewView';
