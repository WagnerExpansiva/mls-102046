/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/workTaskCatalogue.ts" enhancement="_blank"/>
export const qryListWorkTaskRoute = 'buildFlowFsm.workTaskCatalogue.qryListWorkTask';
export const cmdCreateWorkTaskRoute = 'buildFlowFsm.workTaskCatalogue.cmdCreateWorkTask';
export const cmdUpdateWorkTaskRoute = 'buildFlowFsm.workTaskCatalogue.cmdUpdateWorkTask';
export const cmdDeleteWorkTaskRoute = 'buildFlowFsm.workTaskCatalogue.cmdDeleteWorkTask';
