/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/consultClientProjectUpdates.ts" enhancement="_blank"/>
export const qryLocateProjectRoute = 'buildFlowFsm.consultClientProjectUpdates.qryLocateProject';
export const qryInspectStatusReportRoute = 'buildFlowFsm.consultClientProjectUpdates.qryInspectStatusReport';
export const qryInspectClientBillingSummaryRoute = 'buildFlowFsm.consultClientProjectUpdates.qryInspectClientBillingSummary';
