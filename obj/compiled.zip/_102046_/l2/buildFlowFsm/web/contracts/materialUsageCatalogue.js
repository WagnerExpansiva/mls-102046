/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/materialUsageCatalogue.ts" enhancement="_blank"/>
export const qryListMaterialUsageRoute = 'buildFlowFsm.materialUsageCatalogue.qryListMaterialUsage';
export const cmdCreateMaterialUsageRoute = 'buildFlowFsm.materialUsageCatalogue.cmdCreateMaterialUsage';
export const cmdUpdateMaterialUsageRoute = 'buildFlowFsm.materialUsageCatalogue.cmdUpdateMaterialUsage';
export const cmdDeleteMaterialUsageRoute = 'buildFlowFsm.materialUsageCatalogue.cmdDeleteMaterialUsage';
export const qryInventoryBalancePickerRoute = 'buildFlowFsm.materialUsageCatalogue.qryInventoryBalancePicker';
export const qryInventoryItemPickerRoute = 'buildFlowFsm.materialUsageCatalogue.qryInventoryItemPicker';
export const qryProjectPickerRoute = 'buildFlowFsm.materialUsageCatalogue.qryProjectPicker';
