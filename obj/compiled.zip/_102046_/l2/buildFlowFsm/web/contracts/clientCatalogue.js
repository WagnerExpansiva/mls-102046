/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/clientCatalogue.ts" enhancement="_blank"/>
export const qryListClientRoute = 'buildFlowFsm.clientCatalogue.qryListClient';
export const cmdCreateClientRoute = 'buildFlowFsm.clientCatalogue.cmdCreateClient';
export const cmdUpdateClientRoute = 'buildFlowFsm.clientCatalogue.cmdUpdateClient';
export const cmdDeleteClientRoute = 'buildFlowFsm.clientCatalogue.cmdDeleteClient';
