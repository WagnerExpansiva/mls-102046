/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/recordProjectMaterialUsage.ts" enhancement="_blank"/>
export const qryLocateProjectRoute = 'buildFlowFsm.recordProjectMaterialUsage.qryLocateProject';
export const qryLocateInventoryItemRoute = 'buildFlowFsm.recordProjectMaterialUsage.qryLocateInventoryItem';
export const cmdCreateMaterialUsageRoute = 'buildFlowFsm.recordProjectMaterialUsage.cmdCreateMaterialUsage';
export const cmdHandoffMaterialUsageToFieldCoordinatorRoute = 'buildFlowFsm.recordProjectMaterialUsage.cmdHandoffMaterialUsageToFieldCoordinator';
export const qryInventoryBalancePickerRoute = 'buildFlowFsm.recordProjectMaterialUsage.qryInventoryBalancePicker';
