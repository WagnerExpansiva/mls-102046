/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/projectDashboardView.ts" enhancement="_blank"/>
export const qryProjectDashboardViewRoute = 'buildFlowFsm.projectDashboardView.qryProjectDashboardView';
