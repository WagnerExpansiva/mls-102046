/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/recordWorkTime.ts" enhancement="_blank"/>
export const qryLocateFieldWorkerRoute = 'buildFlowFsm.recordWorkTime.qryLocateFieldWorker';
export const qryLocateWorkTaskRoute = 'buildFlowFsm.recordWorkTime.qryLocateWorkTask';
export const cmdCreateTimeLogRoute = 'buildFlowFsm.recordWorkTime.cmdCreateTimeLog';
export const cmdHandoffTimeLogToFieldCoordinatorRoute = 'buildFlowFsm.recordWorkTime.cmdHandoffTimeLogToFieldCoordinator';
