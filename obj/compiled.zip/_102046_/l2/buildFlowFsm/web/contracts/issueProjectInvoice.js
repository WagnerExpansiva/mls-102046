/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/issueProjectInvoice.ts" enhancement="_blank"/>
export const qryLocateClientRoute = 'buildFlowFsm.issueProjectInvoice.qryLocateClient';
export const qryLocateProjectRoute = 'buildFlowFsm.issueProjectInvoice.qryLocateProject';
export const qryInspectClientBillingSummaryRoute = 'buildFlowFsm.issueProjectInvoice.qryInspectClientBillingSummary';
export const cmdCreateInvoiceRoute = 'buildFlowFsm.issueProjectInvoice.cmdCreateInvoice';
export const cmdHandoffInvoiceToClientRoute = 'buildFlowFsm.issueProjectInvoice.cmdHandoffInvoiceToClient';
