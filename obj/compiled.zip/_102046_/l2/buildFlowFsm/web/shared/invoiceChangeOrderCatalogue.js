/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/invoiceChangeOrderCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListInvoiceChangeOrderRoute, cmdCreateInvoiceChangeOrderRoute, cmdUpdateInvoiceChangeOrderRoute, cmdDeleteInvoiceChangeOrderRoute, qryInvoicePickerRoute, qryChangeOrderPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/invoiceChangeOrderCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.invoiceChangeOrderCatalogue.recordList.title': 'Localizar aplicações',
    'organism.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceChangeOrderId.label': 'Invoice Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.action.cmdDeleteInvoiceChangeOrder': 'Excluir Aplicação de ordem de mudança na fatura',
    'section.invoiceChangeOrderCatalogue.recordForm.title': 'Criar ou corrigir aplicação',
    'organism.invoiceChangeOrderCatalogue.qryInvoicePicker.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.clientId.label': 'Client Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.projectId.label': 'Project Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.commercialReference.label': 'Commercial Reference',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.amount.label': 'Amount',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.action.cmdCreateInvoiceChangeOrder': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.action.cmdUpdateInvoiceChangeOrder': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'action.cmdCreateInvoiceChangeOrder.success': 'Criar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdCreateInvoiceChangeOrder.error': 'Criar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdUpdateInvoiceChangeOrder.success': 'Atualizar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdUpdateInvoiceChangeOrder.error': 'Atualizar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdDeleteInvoiceChangeOrder.success': 'Excluir Aplicação de ordem de mudança na fatura: OK',
    'action.cmdDeleteInvoiceChangeOrder.error': 'Excluir Aplicação de ordem de mudança na fatura: falhou',
    'section.invoiceChangeOrderCatalogue.recordWorkbench.title': 'Aplicações vinculadas',
    'section.invoiceChangeOrderCatalogue.newAssociation.title': 'Nova aplicação',
};
const message_pt_br = {
    'section.invoiceChangeOrderCatalogue.recordList.title': 'Localizar aplicações',
    'organism.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceChangeOrderId.label': 'Invoice Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.action.cmdDeleteInvoiceChangeOrder': 'Excluir Aplicação de ordem de mudança na fatura',
    'section.invoiceChangeOrderCatalogue.recordForm.title': 'Criar ou corrigir aplicação',
    'organism.invoiceChangeOrderCatalogue.qryInvoicePicker.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.clientId.label': 'Client Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.projectId.label': 'Project Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.commercialReference.label': 'Commercial Reference',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.amount.label': 'Amount',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.action.cmdCreateInvoiceChangeOrder': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.action.cmdUpdateInvoiceChangeOrder': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'action.cmdCreateInvoiceChangeOrder.success': 'Criar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdCreateInvoiceChangeOrder.error': 'Criar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdUpdateInvoiceChangeOrder.success': 'Atualizar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdUpdateInvoiceChangeOrder.error': 'Atualizar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdDeleteInvoiceChangeOrder.success': 'Excluir Aplicação de ordem de mudança na fatura: OK',
    'action.cmdDeleteInvoiceChangeOrder.error': 'Excluir Aplicação de ordem de mudança na fatura: falhou',
    'section.invoiceChangeOrderCatalogue.recordWorkbench.title': 'Aplicações vinculadas',
    'section.invoiceChangeOrderCatalogue.newAssociation.title': 'Nova aplicação',
};
const message_en = {
    'section.invoiceChangeOrderCatalogue.recordList.title': 'Localizar aplicações',
    'organism.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceChangeOrderId.label': 'Invoice Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.action.cmdDeleteInvoiceChangeOrder': 'Excluir Aplicação de ordem de mudança na fatura',
    'section.invoiceChangeOrderCatalogue.recordForm.title': 'Criar ou corrigir aplicação',
    'organism.invoiceChangeOrderCatalogue.qryInvoicePicker.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.clientId.label': 'Client Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.projectId.label': 'Project Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.commercialReference.label': 'Commercial Reference',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.amount.label': 'Amount',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.action.cmdCreateInvoiceChangeOrder': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.action.cmdUpdateInvoiceChangeOrder': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'action.cmdCreateInvoiceChangeOrder.success': 'Criar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdCreateInvoiceChangeOrder.error': 'Criar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdUpdateInvoiceChangeOrder.success': 'Atualizar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdUpdateInvoiceChangeOrder.error': 'Atualizar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdDeleteInvoiceChangeOrder.success': 'Excluir Aplicação de ordem de mudança na fatura: OK',
    'action.cmdDeleteInvoiceChangeOrder.error': 'Excluir Aplicação de ordem de mudança na fatura: falhou',
    'section.invoiceChangeOrderCatalogue.recordWorkbench.title': 'Aplicações vinculadas',
    'section.invoiceChangeOrderCatalogue.newAssociation.title': 'Nova aplicação',
};
const message_es = {
    'section.invoiceChangeOrderCatalogue.recordList.title': 'Localizar aplicações',
    'organism.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.title': 'Listar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceChangeOrderId.label': 'Invoice Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder.list.column.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.title': 'Excluir Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder.form.action.cmdDeleteInvoiceChangeOrder': 'Excluir Aplicação de ordem de mudança na fatura',
    'section.invoiceChangeOrderCatalogue.recordForm.title': 'Criar ou corrigir aplicação',
    'organism.invoiceChangeOrderCatalogue.qryInvoicePicker.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.title': 'Listar Fatura',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.invoiceId.label': 'Invoice Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.clientId.label': 'Client Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.projectId.label': 'Project Id',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.commercialReference.label': 'Commercial Reference',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.amount.label': 'Amount',
    'intent.invoiceChangeOrderCatalogue.qryInvoicePicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.invoiceChangeOrderCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'organism.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.title': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.action.cmdCreateInvoiceChangeOrder': 'Criar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'organism.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.title': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.action.cmdUpdateInvoiceChangeOrder': 'Atualizar Aplicação de ordem de mudança na fatura',
    'intent.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder.form.field.billedAmount.label': 'Billed Amount',
    'action.cmdCreateInvoiceChangeOrder.success': 'Criar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdCreateInvoiceChangeOrder.error': 'Criar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdUpdateInvoiceChangeOrder.success': 'Atualizar Aplicação de ordem de mudança na fatura: OK',
    'action.cmdUpdateInvoiceChangeOrder.error': 'Atualizar Aplicação de ordem de mudança na fatura: falhou',
    'action.cmdDeleteInvoiceChangeOrder.success': 'Excluir Aplicação de ordem de mudança na fatura: OK',
    'action.cmdDeleteInvoiceChangeOrder.error': 'Excluir Aplicação de ordem de mudança na fatura: falhou',
    'section.invoiceChangeOrderCatalogue.recordWorkbench.title': 'Aplicações vinculadas',
    'section.invoiceChangeOrderCatalogue.newAssociation.title': 'Nova aplicação',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.invoiceChangeOrderCatalogue.status',
    'ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status',
    'ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder',
    'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status',
    'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId',
    'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId',
    'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount',
    'ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder',
    'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error',
    'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status',
    'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId',
    'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId',
    'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId',
    'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount',
    'ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder',
    'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error',
    'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status',
    'ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId',
    'ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder',
    'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error',
    'ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status',
    'ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker',
    'ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status',
    'ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker',
];
export class BuildFlowFsmInvoiceChangeOrderCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListInvoiceChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.qryListInvoiceChangeOrderState = 'idle';
        /** state qryListInvoiceChangeOrderData — queryResult, outputShape: array */
        this.qryListInvoiceChangeOrderData = [];
        /** state cmdCreateInvoiceChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateInvoiceChangeOrderState = 'idle';
        /** state cmdCreateInvoiceChangeOrderInvoiceId — input */
        this.cmdCreateInvoiceChangeOrderInvoiceId = '';
        /** state cmdCreateInvoiceChangeOrderChangeOrderId — input */
        this.cmdCreateInvoiceChangeOrderChangeOrderId = '';
        /** state cmdCreateInvoiceChangeOrderBilledAmount — input */
        this.cmdCreateInvoiceChangeOrderBilledAmount = '';
        /** state cmdCreateInvoiceChangeOrderOutput — commandOutput */
        this.cmdCreateInvoiceChangeOrderOutput = null;
        /** state cmdCreateInvoiceChangeOrderError — actionError */
        this.cmdCreateInvoiceChangeOrderError = '';
        /** state cmdUpdateInvoiceChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateInvoiceChangeOrderState = 'idle';
        /** state cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId — input */
        this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId = '';
        /** state cmdUpdateInvoiceChangeOrderInvoiceId — input */
        this.cmdUpdateInvoiceChangeOrderInvoiceId = '';
        /** state cmdUpdateInvoiceChangeOrderChangeOrderId — input */
        this.cmdUpdateInvoiceChangeOrderChangeOrderId = '';
        /** state cmdUpdateInvoiceChangeOrderBilledAmount — input */
        this.cmdUpdateInvoiceChangeOrderBilledAmount = '';
        /** state cmdUpdateInvoiceChangeOrderOutput — commandOutput */
        this.cmdUpdateInvoiceChangeOrderOutput = null;
        /** state cmdUpdateInvoiceChangeOrderError — actionError */
        this.cmdUpdateInvoiceChangeOrderError = '';
        /** state cmdDeleteInvoiceChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteInvoiceChangeOrderState = 'idle';
        /** state cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId — input */
        this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId = '';
        /** state cmdDeleteInvoiceChangeOrderOutput — commandOutput */
        this.cmdDeleteInvoiceChangeOrderOutput = null;
        /** state cmdDeleteInvoiceChangeOrderError — actionError */
        this.cmdDeleteInvoiceChangeOrderError = '';
        /** state qryInvoicePickerState — actionStatus, values: idle|loading|success|error */
        this.qryInvoicePickerState = 'idle';
        /** state qryInvoicePickerData — queryResult, outputShape: array */
        this.qryInvoicePickerData = [];
        /** state qryChangeOrderPickerState — actionStatus, values: idle|loading|success|error */
        this.qryChangeOrderPickerState = 'idle';
        /** state qryChangeOrderPickerData — queryResult, outputShape: array */
        this.qryChangeOrderPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.invoiceChangeOrderCatalogue.status', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder', []);
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder', null);
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder', null);
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder', null);
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error', '');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker', []);
        this.initStateValue('ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status', 'idle');
        this.initStateValue('ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker', []);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListInvoiceChangeOrder();
        void this.loadQryInvoicePicker();
        void this.loadQryChangeOrderPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.invoiceChangeOrderCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status':
                this.qryListInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder':
                this.qryListInvoiceChangeOrderData = value ?? [];
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status':
                this.cmdCreateInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId':
                this.cmdCreateInvoiceChangeOrderInvoiceId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId':
                this.cmdCreateInvoiceChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount':
                this.cmdCreateInvoiceChangeOrderBilledAmount = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder':
                this.cmdCreateInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error':
                this.cmdCreateInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status':
                this.cmdUpdateInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId':
                this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId':
                this.cmdUpdateInvoiceChangeOrderInvoiceId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId':
                this.cmdUpdateInvoiceChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount':
                this.cmdUpdateInvoiceChangeOrderBilledAmount = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder':
                this.cmdUpdateInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error':
                this.cmdUpdateInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status':
                this.cmdDeleteInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId':
                this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder':
                this.cmdDeleteInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error':
                this.cmdDeleteInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status':
                this.qryInvoicePickerState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker':
                this.qryInvoicePickerData = value ?? [];
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status':
                this.qryChangeOrderPickerState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker':
                this.qryChangeOrderPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.invoiceChangeOrderCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status':
                this.qryListInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder':
                this.qryListInvoiceChangeOrderData = value ?? [];
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status':
                this.cmdCreateInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId':
                this.cmdCreateInvoiceChangeOrderInvoiceId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId':
                this.cmdCreateInvoiceChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount':
                this.cmdCreateInvoiceChangeOrderBilledAmount = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder':
                this.cmdCreateInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error':
                this.cmdCreateInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status':
                this.cmdUpdateInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId':
                this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId':
                this.cmdUpdateInvoiceChangeOrderInvoiceId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId':
                this.cmdUpdateInvoiceChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount':
                this.cmdUpdateInvoiceChangeOrderBilledAmount = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder':
                this.cmdUpdateInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error':
                this.cmdUpdateInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status':
                this.cmdDeleteInvoiceChangeOrderState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId':
                this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder':
                this.cmdDeleteInvoiceChangeOrderOutput = value ?? null;
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error':
                this.cmdDeleteInvoiceChangeOrderError = value ?? '';
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status':
                this.qryInvoicePickerState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker':
                this.qryInvoicePickerData = value ?? [];
                break;
            case 'ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status':
                this.qryChangeOrderPickerState = value ?? 'idle';
                break;
            case 'ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker':
                this.qryChangeOrderPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListInvoiceChangeOrder (query) — route buildFlowFsm.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder; inputs: (none); writes ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder; status ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status */
    async loadQryListInvoiceChangeOrder() {
        this.qryListInvoiceChangeOrderState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListInvoiceChangeOrderRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListInvoiceChangeOrderData = data;
            setState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder', data);
            this.qryListInvoiceChangeOrderState = 'success';
            setState('ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status', 'success');
        }
        else {
            this.qryListInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.qryListInvoiceChangeOrder.status', 'error');
            if (response.error) {
                console.error('qryListInvoiceChangeOrder failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListInvoiceChangeOrder — bind UI events here */
    handleQryListInvoiceChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListInvoiceChangeOrder();
    }
    /** action cmdCreateInvoiceChangeOrder (command) — route buildFlowFsm.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder; inputs: invoiceId, changeOrderId, billedAmount; writes ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder; status ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status; feedback keys action.cmdCreateInvoiceChangeOrder.success / action.cmdCreateInvoiceChangeOrder.error */
    async cmdCreateInvoiceChangeOrder() {
        if (!this.cmdCreateInvoiceChangeOrderInvoiceId) {
            this.cmdCreateInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdCreateInvoiceChangeOrderChangeOrderId) {
            this.cmdCreateInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdCreateInvoiceChangeOrderState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'loading');
        this.cmdCreateInvoiceChangeOrderError = '';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error', '');
        const billedAmountNum = Number(this.cmdCreateInvoiceChangeOrderBilledAmount);
        const params = {
            invoiceId: this.cmdCreateInvoiceChangeOrderInvoiceId,
            changeOrderId: this.cmdCreateInvoiceChangeOrderChangeOrderId,
            billedAmount: Number.isNaN(billedAmountNum) ? 0 : billedAmountNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateInvoiceChangeOrderRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateInvoiceChangeOrder.error');
            this.cmdCreateInvoiceChangeOrderError = errMsg;
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.error', errMsg);
            this.cmdCreateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateInvoiceChangeOrderOutput = data;
        setState('ui.invoiceChangeOrderCatalogue.output.cmdCreateInvoiceChangeOrder', data);
        try {
            await this.loadQryListInvoiceChangeOrder();
            if (this.qryListInvoiceChangeOrderState === 'error') {
                this.cmdCreateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdCreateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInvoicePicker();
            if (this.qryInvoicePickerState === 'error') {
                this.cmdCreateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdCreateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdCreateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdCreateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateInvoiceChangeOrderInvoiceId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId', '');
        this.cmdCreateInvoiceChangeOrderChangeOrderId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId', '');
        this.cmdCreateInvoiceChangeOrderBilledAmount = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount', '');
        this.cmdCreateInvoiceChangeOrderState = 'success';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdCreateInvoiceChangeOrder.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateInvoiceChangeOrder — bind UI events here */
    handleCmdCreateInvoiceChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateInvoiceChangeOrder();
        });
    }
    /** action cmdUpdateInvoiceChangeOrder (command) — route buildFlowFsm.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder; inputs: invoiceChangeOrderId, invoiceId, changeOrderId, billedAmount; writes ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder; status ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status; feedback keys action.cmdUpdateInvoiceChangeOrder.success / action.cmdUpdateInvoiceChangeOrder.error */
    async cmdUpdateInvoiceChangeOrder() {
        if (!this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId) {
            this.cmdUpdateInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateInvoiceChangeOrderInvoiceId) {
            this.cmdUpdateInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateInvoiceChangeOrderChangeOrderId) {
            this.cmdUpdateInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateInvoiceChangeOrderState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'loading');
        this.cmdUpdateInvoiceChangeOrderError = '';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error', '');
        const billedAmountNum = Number(this.cmdUpdateInvoiceChangeOrderBilledAmount);
        const params = {
            invoiceChangeOrderId: this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId,
            invoiceId: this.cmdUpdateInvoiceChangeOrderInvoiceId,
            changeOrderId: this.cmdUpdateInvoiceChangeOrderChangeOrderId,
            billedAmount: Number.isNaN(billedAmountNum) ? 0 : billedAmountNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateInvoiceChangeOrderRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateInvoiceChangeOrder.error');
            this.cmdUpdateInvoiceChangeOrderError = errMsg;
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.error', errMsg);
            this.cmdUpdateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateInvoiceChangeOrderOutput = data;
        setState('ui.invoiceChangeOrderCatalogue.output.cmdUpdateInvoiceChangeOrder', data);
        try {
            await this.loadQryListInvoiceChangeOrder();
            if (this.qryListInvoiceChangeOrderState === 'error') {
                this.cmdUpdateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdUpdateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInvoicePicker();
            if (this.qryInvoicePickerState === 'error') {
                this.cmdUpdateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdUpdateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdUpdateInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateInvoiceChangeOrder refresh failed', refreshError);
            this.cmdUpdateInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId', '');
        this.cmdUpdateInvoiceChangeOrderInvoiceId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId', '');
        this.cmdUpdateInvoiceChangeOrderChangeOrderId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId', '');
        this.cmdUpdateInvoiceChangeOrderBilledAmount = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', '');
        this.cmdUpdateInvoiceChangeOrderState = 'success';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdUpdateInvoiceChangeOrder.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateInvoiceChangeOrder — bind UI events here */
    handleCmdUpdateInvoiceChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateInvoiceChangeOrder();
        });
    }
    /** action cmdDeleteInvoiceChangeOrder (command) — route buildFlowFsm.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder; inputs: invoiceChangeOrderId; writes ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder; status ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status; feedback keys action.cmdDeleteInvoiceChangeOrder.success / action.cmdDeleteInvoiceChangeOrder.error */
    async cmdDeleteInvoiceChangeOrder() {
        if (!this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId) {
            this.cmdDeleteInvoiceChangeOrderState = 'idle';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteInvoiceChangeOrderState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'loading');
        this.cmdDeleteInvoiceChangeOrderError = '';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error', '');
        const params = {
            invoiceChangeOrderId: this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteInvoiceChangeOrderRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteInvoiceChangeOrder.error');
            this.cmdDeleteInvoiceChangeOrderError = errMsg;
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.error', errMsg);
            this.cmdDeleteInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteInvoiceChangeOrderOutput = data;
        setState('ui.invoiceChangeOrderCatalogue.output.cmdDeleteInvoiceChangeOrder', data);
        try {
            await this.loadQryListInvoiceChangeOrder();
            if (this.qryListInvoiceChangeOrderState === 'error') {
                this.cmdDeleteInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteInvoiceChangeOrder refresh failed', refreshError);
            this.cmdDeleteInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInvoicePicker();
            if (this.qryInvoicePickerState === 'error') {
                this.cmdDeleteInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteInvoiceChangeOrder refresh failed', refreshError);
            this.cmdDeleteInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdDeleteInvoiceChangeOrderState = 'error';
                setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteInvoiceChangeOrder refresh failed', refreshError);
            this.cmdDeleteInvoiceChangeOrderState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId = '';
        setState('ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId', '');
        this.cmdDeleteInvoiceChangeOrderState = 'success';
        setState('ui.invoiceChangeOrderCatalogue.action.cmdDeleteInvoiceChangeOrder.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteInvoiceChangeOrder — bind UI events here */
    handleCmdDeleteInvoiceChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteInvoiceChangeOrder();
        });
    }
    /** action qryInvoicePicker (query) — route buildFlowFsm.invoiceChangeOrderCatalogue.qryInvoicePicker; inputs: (none); writes ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker; status ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status */
    async loadQryInvoicePicker() {
        this.qryInvoicePickerState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryInvoicePickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryInvoicePickerData = data;
            setState('ui.invoiceChangeOrderCatalogue.data.qryInvoicePicker', data);
            this.qryInvoicePickerState = 'success';
            setState('ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status', 'success');
        }
        else {
            this.qryInvoicePickerState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.qryInvoicePicker.status', 'error');
            if (response.error) {
                console.error('qryInvoicePicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInvoicePicker — bind UI events here */
    handleQryInvoicePickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInvoicePicker();
    }
    /** action qryChangeOrderPicker (query) — route buildFlowFsm.invoiceChangeOrderCatalogue.qryChangeOrderPicker; inputs: (none); writes ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker; status ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status */
    async loadQryChangeOrderPicker() {
        this.qryChangeOrderPickerState = 'loading';
        setState('ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryChangeOrderPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryChangeOrderPickerData = data;
            setState('ui.invoiceChangeOrderCatalogue.data.qryChangeOrderPicker', data);
            this.qryChangeOrderPickerState = 'success';
            setState('ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status', 'success');
        }
        else {
            this.qryChangeOrderPickerState = 'error';
            setState('ui.invoiceChangeOrderCatalogue.action.qryChangeOrderPicker.status', 'error');
            if (response.error) {
                console.error('qryChangeOrderPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryChangeOrderPicker — bind UI events here */
    handleQryChangeOrderPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryChangeOrderPicker();
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId */
    setCmdCreateInvoiceChangeOrderInvoiceId(value) {
        this.cmdCreateInvoiceChangeOrderInvoiceId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.invoiceId', value);
        const collection = getState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder') ?? this.qryListInvoiceChangeOrderData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.invoiceId) === String(value));
            if (item) {
                this.cmdCreateInvoiceChangeOrderBilledAmount = String(item.billedAmount);
                setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount', String(item.billedAmount));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateInvoiceChangeOrderInvoiceId — bind UI events here */
    handleCmdCreateInvoiceChangeOrderInvoiceIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateInvoiceChangeOrderInvoiceId(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId */
    setCmdCreateInvoiceChangeOrderChangeOrderId(value) {
        this.cmdCreateInvoiceChangeOrderChangeOrderId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.changeOrderId', value);
        const collection = getState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder') ?? this.qryListInvoiceChangeOrderData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.changeOrderId) === String(value));
            if (item) {
                this.cmdCreateInvoiceChangeOrderBilledAmount = String(item.billedAmount);
                setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount', String(item.billedAmount));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateInvoiceChangeOrderChangeOrderId — bind UI events here */
    handleCmdCreateInvoiceChangeOrderChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateInvoiceChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount */
    setCmdCreateInvoiceChangeOrderBilledAmount(value) {
        this.cmdCreateInvoiceChangeOrderBilledAmount = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdCreateInvoiceChangeOrder.billedAmount', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateInvoiceChangeOrderBilledAmount — bind UI events here */
    handleCmdCreateInvoiceChangeOrderBilledAmountChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateInvoiceChangeOrderBilledAmount(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId */
    setCmdUpdateInvoiceChangeOrderInvoiceChangeOrderId(value) {
        this.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceChangeOrderId', value);
        const collection = getState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder') ?? this.qryListInvoiceChangeOrderData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.invoiceChangeOrderId) === String(value));
            if (item) {
                this.cmdUpdateInvoiceChangeOrderBilledAmount = String(item.billedAmount);
                setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', String(item.billedAmount));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId — bind UI events here */
    handleCmdUpdateInvoiceChangeOrderInvoiceChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateInvoiceChangeOrderInvoiceChangeOrderId(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId */
    setCmdUpdateInvoiceChangeOrderInvoiceId(value) {
        this.cmdUpdateInvoiceChangeOrderInvoiceId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.invoiceId', value);
        const collection = getState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder') ?? this.qryListInvoiceChangeOrderData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.invoiceId) === String(value));
            if (item) {
                this.cmdUpdateInvoiceChangeOrderBilledAmount = String(item.billedAmount);
                setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', String(item.billedAmount));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateInvoiceChangeOrderInvoiceId — bind UI events here */
    handleCmdUpdateInvoiceChangeOrderInvoiceIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateInvoiceChangeOrderInvoiceId(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId */
    setCmdUpdateInvoiceChangeOrderChangeOrderId(value) {
        this.cmdUpdateInvoiceChangeOrderChangeOrderId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.changeOrderId', value);
        const collection = getState('ui.invoiceChangeOrderCatalogue.data.qryListInvoiceChangeOrder') ?? this.qryListInvoiceChangeOrderData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.changeOrderId) === String(value));
            if (item) {
                this.cmdUpdateInvoiceChangeOrderBilledAmount = String(item.billedAmount);
                setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', String(item.billedAmount));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateInvoiceChangeOrderChangeOrderId — bind UI events here */
    handleCmdUpdateInvoiceChangeOrderChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateInvoiceChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount */
    setCmdUpdateInvoiceChangeOrderBilledAmount(value) {
        this.cmdUpdateInvoiceChangeOrderBilledAmount = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdUpdateInvoiceChangeOrder.billedAmount', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateInvoiceChangeOrderBilledAmount — bind UI events here */
    handleCmdUpdateInvoiceChangeOrderBilledAmountChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateInvoiceChangeOrderBilledAmount(value);
    }
    /** setter for state ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId */
    setCmdDeleteInvoiceChangeOrderInvoiceChangeOrderId(value) {
        this.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId = value;
        setState('ui.invoiceChangeOrderCatalogue.input.cmdDeleteInvoiceChangeOrder.invoiceChangeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId — bind UI events here */
    handleCmdDeleteInvoiceChangeOrderInvoiceChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteInvoiceChangeOrderInvoiceChangeOrderId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryListInvoiceChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryListInvoiceChangeOrderData", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderInvoiceId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderBilledAmount", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdCreateInvoiceChangeOrderError", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderInvoiceChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderInvoiceId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderBilledAmount", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdUpdateInvoiceChangeOrderError", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdDeleteInvoiceChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdDeleteInvoiceChangeOrderInvoiceChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdDeleteInvoiceChangeOrderOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "cmdDeleteInvoiceChangeOrderError", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryInvoicePickerState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryInvoicePickerData", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryChangeOrderPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceChangeOrderCatalogueBase.prototype, "qryChangeOrderPickerData", void 0);
