/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/materialUsageCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListMaterialUsageRoute, cmdCreateMaterialUsageRoute, cmdUpdateMaterialUsageRoute, cmdDeleteMaterialUsageRoute, qryInventoryBalancePickerRoute, qryInventoryItemPickerRoute, qryProjectPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/materialUsageCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.materialUsageCatalogue.recordList.title': 'Consumos registrados',
    'organism.materialUsageCatalogue.qryListMaterialUsage.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.cmdDeleteMaterialUsage.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.action.cmdDeleteMaterialUsage': 'Excluir Consumo de material',
    'section.materialUsageCatalogue.recordForm.title': 'Registrar ou corrigir consumo',
    'organism.materialUsageCatalogue.cmdCreateMaterialUsage.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.action.cmdCreateMaterialUsage': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.qryInventoryBalancePicker.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.physicalQuantity.label': 'Physical Quantity',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.applicableUnitCost.label': 'Applicable Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryInventoryItemPicker.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.description.label': 'Description',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.unitOfMeasure.label': 'Unit Of Measure',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.referenceUnitCost.label': 'Reference Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryProjectPicker.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.clientId.label': 'Client Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.address.label': 'Address',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.materialUsageCatalogue.cmdUpdateMaterialUsage.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.action.cmdUpdateMaterialUsage': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.status.label': 'Status',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'action.cmdCreateMaterialUsage.success': 'Registrar o consumo de material: OK',
    'action.cmdCreateMaterialUsage.error': 'Registrar o consumo de material: falhou',
    'action.cmdUpdateMaterialUsage.success': 'Atualizar Consumo de material: OK',
    'action.cmdUpdateMaterialUsage.error': 'Atualizar Consumo de material: falhou',
    'action.cmdDeleteMaterialUsage.success': 'Excluir Consumo de material: OK',
    'action.cmdDeleteMaterialUsage.error': 'Excluir Consumo de material: falhou',
    'section.materialUsageCatalogue.usageWorkbench.title': 'Consumos de material',
};
const message_pt_br = {
    'section.materialUsageCatalogue.recordList.title': 'Consumos registrados',
    'organism.materialUsageCatalogue.qryListMaterialUsage.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.cmdDeleteMaterialUsage.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.action.cmdDeleteMaterialUsage': 'Excluir Consumo de material',
    'section.materialUsageCatalogue.recordForm.title': 'Registrar ou corrigir consumo',
    'organism.materialUsageCatalogue.cmdCreateMaterialUsage.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.action.cmdCreateMaterialUsage': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.qryInventoryBalancePicker.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.physicalQuantity.label': 'Physical Quantity',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.applicableUnitCost.label': 'Applicable Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryInventoryItemPicker.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.description.label': 'Description',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.unitOfMeasure.label': 'Unit Of Measure',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.referenceUnitCost.label': 'Reference Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryProjectPicker.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.clientId.label': 'Client Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.address.label': 'Address',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.materialUsageCatalogue.cmdUpdateMaterialUsage.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.action.cmdUpdateMaterialUsage': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.status.label': 'Status',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'action.cmdCreateMaterialUsage.success': 'Registrar o consumo de material: OK',
    'action.cmdCreateMaterialUsage.error': 'Registrar o consumo de material: falhou',
    'action.cmdUpdateMaterialUsage.success': 'Atualizar Consumo de material: OK',
    'action.cmdUpdateMaterialUsage.error': 'Atualizar Consumo de material: falhou',
    'action.cmdDeleteMaterialUsage.success': 'Excluir Consumo de material: OK',
    'action.cmdDeleteMaterialUsage.error': 'Excluir Consumo de material: falhou',
    'section.materialUsageCatalogue.usageWorkbench.title': 'Consumos de material',
};
const message_en = {
    'section.materialUsageCatalogue.recordList.title': 'Consumos registrados',
    'organism.materialUsageCatalogue.qryListMaterialUsage.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.cmdDeleteMaterialUsage.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.action.cmdDeleteMaterialUsage': 'Excluir Consumo de material',
    'section.materialUsageCatalogue.recordForm.title': 'Registrar ou corrigir consumo',
    'organism.materialUsageCatalogue.cmdCreateMaterialUsage.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.action.cmdCreateMaterialUsage': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.qryInventoryBalancePicker.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.physicalQuantity.label': 'Physical Quantity',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.applicableUnitCost.label': 'Applicable Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryInventoryItemPicker.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.description.label': 'Description',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.unitOfMeasure.label': 'Unit Of Measure',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.referenceUnitCost.label': 'Reference Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryProjectPicker.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.clientId.label': 'Client Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.address.label': 'Address',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.materialUsageCatalogue.cmdUpdateMaterialUsage.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.action.cmdUpdateMaterialUsage': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.status.label': 'Status',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'action.cmdCreateMaterialUsage.success': 'Registrar o consumo de material: OK',
    'action.cmdCreateMaterialUsage.error': 'Registrar o consumo de material: falhou',
    'action.cmdUpdateMaterialUsage.success': 'Atualizar Consumo de material: OK',
    'action.cmdUpdateMaterialUsage.error': 'Atualizar Consumo de material: falhou',
    'action.cmdDeleteMaterialUsage.success': 'Excluir Consumo de material: OK',
    'action.cmdDeleteMaterialUsage.error': 'Excluir Consumo de material: falhou',
    'section.materialUsageCatalogue.usageWorkbench.title': 'Consumos de material',
};
const message_es = {
    'section.materialUsageCatalogue.recordList.title': 'Consumos registrados',
    'organism.materialUsageCatalogue.qryListMaterialUsage.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.title': 'Listar Consumo de material',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.qryListMaterialUsage.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.cmdDeleteMaterialUsage.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.title': 'Excluir Consumo de material',
    'intent.materialUsageCatalogue.cmdDeleteMaterialUsage.form.action.cmdDeleteMaterialUsage': 'Excluir Consumo de material',
    'section.materialUsageCatalogue.recordForm.title': 'Registrar ou corrigir consumo',
    'organism.materialUsageCatalogue.cmdCreateMaterialUsage.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.title': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.action.cmdCreateMaterialUsage': 'Registrar o consumo de material',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdCreateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'organism.materialUsageCatalogue.qryInventoryBalancePicker.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.title': 'Listar Saldo de estoque',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.physicalQuantity.label': 'Physical Quantity',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.applicableUnitCost.label': 'Applicable Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryBalancePicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryInventoryItemPicker.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.title': 'Listar Item de estoque',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.description.label': 'Description',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.unitOfMeasure.label': 'Unit Of Measure',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.referenceUnitCost.label': 'Reference Unit Cost',
    'intent.materialUsageCatalogue.qryInventoryItemPicker.list.column.status.label': 'Status',
    'organism.materialUsageCatalogue.qryProjectPicker.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.title': 'Listar Obra',
    'intent.materialUsageCatalogue.qryProjectPicker.list.empty': 'Nenhum registro encontrado',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.projectId.label': 'Project Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.clientId.label': 'Client Id',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.name.label': 'Name',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.address.label': 'Address',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.status.label': 'Status',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.materialUsageCatalogue.qryProjectPicker.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.materialUsageCatalogue.cmdUpdateMaterialUsage.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.title': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.action.cmdUpdateMaterialUsage': 'Atualizar Consumo de material',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.status.label': 'Status',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.usageDescription.label': 'Usage Description',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.consumedOn.label': 'Consumed On',
    'intent.materialUsageCatalogue.cmdUpdateMaterialUsage.form.field.unitCostBasis.label': 'Unit Cost Basis',
    'action.cmdCreateMaterialUsage.success': 'Registrar o consumo de material: OK',
    'action.cmdCreateMaterialUsage.error': 'Registrar o consumo de material: falhou',
    'action.cmdUpdateMaterialUsage.success': 'Atualizar Consumo de material: OK',
    'action.cmdUpdateMaterialUsage.error': 'Atualizar Consumo de material: falhou',
    'action.cmdDeleteMaterialUsage.success': 'Excluir Consumo de material: OK',
    'action.cmdDeleteMaterialUsage.error': 'Excluir Consumo de material: falhou',
    'section.materialUsageCatalogue.usageWorkbench.title': 'Consumos de material',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.materialUsageCatalogue.status',
    'ui.materialUsageCatalogue.action.qryListMaterialUsage.status',
    'ui.materialUsageCatalogue.data.qryListMaterialUsage',
    'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn',
    'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis',
    'ui.materialUsageCatalogue.output.cmdCreateMaterialUsage',
    'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error',
    'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn',
    'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis',
    'ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage',
    'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error',
    'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status',
    'ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId',
    'ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage',
    'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error',
    'ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status',
    'ui.materialUsageCatalogue.data.qryInventoryBalancePicker',
    'ui.materialUsageCatalogue.action.qryInventoryItemPicker.status',
    'ui.materialUsageCatalogue.data.qryInventoryItemPicker',
    'ui.materialUsageCatalogue.action.qryProjectPicker.status',
    'ui.materialUsageCatalogue.data.qryProjectPicker',
];
export class BuildFlowFsmMaterialUsageCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.qryListMaterialUsageState = 'idle';
        /** state qryListMaterialUsageData — queryResult, outputShape: array */
        this.qryListMaterialUsageData = [];
        /** state cmdCreateMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateMaterialUsageState = 'idle';
        /** state cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId — input */
        this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId = '';
        /** state cmdCreateMaterialUsageInventoryItemInventoryItemId — input */
        this.cmdCreateMaterialUsageInventoryItemInventoryItemId = '';
        /** state cmdCreateMaterialUsageProjectProjectId — input */
        this.cmdCreateMaterialUsageProjectProjectId = '';
        /** state cmdCreateMaterialUsageQuantity — input */
        this.cmdCreateMaterialUsageQuantity = '';
        /** state cmdCreateMaterialUsageUsageDescription — input */
        this.cmdCreateMaterialUsageUsageDescription = '';
        /** state cmdCreateMaterialUsageConsumedOn — input */
        this.cmdCreateMaterialUsageConsumedOn = '';
        /** state cmdCreateMaterialUsageUnitCostBasis — input */
        this.cmdCreateMaterialUsageUnitCostBasis = '';
        /** state cmdCreateMaterialUsageOutput — commandOutput */
        this.cmdCreateMaterialUsageOutput = null;
        /** state cmdCreateMaterialUsageError — actionError */
        this.cmdCreateMaterialUsageError = '';
        /** state cmdUpdateMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateMaterialUsageState = 'idle';
        /** state cmdUpdateMaterialUsageMaterialUsageId — input */
        this.cmdUpdateMaterialUsageMaterialUsageId = '';
        /** state cmdUpdateMaterialUsageStatus — input */
        this.cmdUpdateMaterialUsageStatus = '';
        /** state cmdUpdateMaterialUsageProjectId — input */
        this.cmdUpdateMaterialUsageProjectId = '';
        /** state cmdUpdateMaterialUsageInventoryItemId — input */
        this.cmdUpdateMaterialUsageInventoryItemId = '';
        /** state cmdUpdateMaterialUsageInventoryBalanceId — input */
        this.cmdUpdateMaterialUsageInventoryBalanceId = '';
        /** state cmdUpdateMaterialUsageQuantity — input */
        this.cmdUpdateMaterialUsageQuantity = '';
        /** state cmdUpdateMaterialUsageUsageDescription — input */
        this.cmdUpdateMaterialUsageUsageDescription = '';
        /** state cmdUpdateMaterialUsageConsumedOn — input */
        this.cmdUpdateMaterialUsageConsumedOn = '';
        /** state cmdUpdateMaterialUsageUnitCostBasis — input */
        this.cmdUpdateMaterialUsageUnitCostBasis = '';
        /** state cmdUpdateMaterialUsageOutput — commandOutput */
        this.cmdUpdateMaterialUsageOutput = null;
        /** state cmdUpdateMaterialUsageError — actionError */
        this.cmdUpdateMaterialUsageError = '';
        /** state cmdDeleteMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteMaterialUsageState = 'idle';
        /** state cmdDeleteMaterialUsageMaterialUsageId — input */
        this.cmdDeleteMaterialUsageMaterialUsageId = '';
        /** state cmdDeleteMaterialUsageOutput — commandOutput */
        this.cmdDeleteMaterialUsageOutput = null;
        /** state cmdDeleteMaterialUsageError — actionError */
        this.cmdDeleteMaterialUsageError = '';
        /** state qryInventoryBalancePickerState — actionStatus, values: idle|loading|success|error */
        this.qryInventoryBalancePickerState = 'idle';
        /** state qryInventoryBalancePickerData — queryResult, outputShape: array */
        this.qryInventoryBalancePickerData = [];
        /** state qryInventoryItemPickerState — actionStatus, values: idle|loading|success|error */
        this.qryInventoryItemPickerState = 'idle';
        /** state qryInventoryItemPickerData — queryResult, outputShape: array */
        this.qryInventoryItemPickerData = [];
        /** state qryProjectPickerState — actionStatus, values: idle|loading|success|error */
        this.qryProjectPickerState = 'idle';
        /** state qryProjectPickerData — queryResult, outputShape: array */
        this.qryProjectPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.materialUsageCatalogue.status', '');
        this.initStateValue('ui.materialUsageCatalogue.action.qryListMaterialUsage.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.data.qryListMaterialUsage', []);
        this.initStateValue('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis', '');
        this.initStateValue('ui.materialUsageCatalogue.output.cmdCreateMaterialUsage', null);
        this.initStateValue('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error', '');
        this.initStateValue('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', '');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', '');
        this.initStateValue('ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage', null);
        this.initStateValue('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error', '');
        this.initStateValue('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId', '');
        this.initStateValue('ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage', null);
        this.initStateValue('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error', '');
        this.initStateValue('ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.data.qryInventoryBalancePicker', []);
        this.initStateValue('ui.materialUsageCatalogue.action.qryInventoryItemPicker.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.data.qryInventoryItemPicker', []);
        this.initStateValue('ui.materialUsageCatalogue.action.qryProjectPicker.status', 'idle');
        this.initStateValue('ui.materialUsageCatalogue.data.qryProjectPicker', []);
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListMaterialUsage();
        void this.loadQryInventoryBalancePicker();
        void this.loadQryInventoryItemPicker();
        void this.loadQryProjectPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.materialUsageCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.qryListMaterialUsage.status':
                this.qryListMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryListMaterialUsage':
                this.qryListMaterialUsageData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status':
                this.cmdCreateMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId':
                this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId':
                this.cmdCreateMaterialUsageInventoryItemInventoryItemId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId':
                this.cmdCreateMaterialUsageProjectProjectId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity':
                this.cmdCreateMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription':
                this.cmdCreateMaterialUsageUsageDescription = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn':
                this.cmdCreateMaterialUsageConsumedOn = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis':
                this.cmdCreateMaterialUsageUnitCostBasis = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdCreateMaterialUsage':
                this.cmdCreateMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error':
                this.cmdCreateMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status':
                this.cmdUpdateMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId':
                this.cmdUpdateMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status':
                this.cmdUpdateMaterialUsageStatus = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId':
                this.cmdUpdateMaterialUsageProjectId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId':
                this.cmdUpdateMaterialUsageInventoryItemId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId':
                this.cmdUpdateMaterialUsageInventoryBalanceId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity':
                this.cmdUpdateMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription':
                this.cmdUpdateMaterialUsageUsageDescription = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn':
                this.cmdUpdateMaterialUsageConsumedOn = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis':
                this.cmdUpdateMaterialUsageUnitCostBasis = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage':
                this.cmdUpdateMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error':
                this.cmdUpdateMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status':
                this.cmdDeleteMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId':
                this.cmdDeleteMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage':
                this.cmdDeleteMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error':
                this.cmdDeleteMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status':
                this.qryInventoryBalancePickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryInventoryBalancePicker':
                this.qryInventoryBalancePickerData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.qryInventoryItemPicker.status':
                this.qryInventoryItemPickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryInventoryItemPicker':
                this.qryInventoryItemPickerData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.qryProjectPicker.status':
                this.qryProjectPickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryProjectPicker':
                this.qryProjectPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.materialUsageCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.qryListMaterialUsage.status':
                this.qryListMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryListMaterialUsage':
                this.qryListMaterialUsageData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status':
                this.cmdCreateMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId':
                this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId':
                this.cmdCreateMaterialUsageInventoryItemInventoryItemId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId':
                this.cmdCreateMaterialUsageProjectProjectId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity':
                this.cmdCreateMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription':
                this.cmdCreateMaterialUsageUsageDescription = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn':
                this.cmdCreateMaterialUsageConsumedOn = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis':
                this.cmdCreateMaterialUsageUnitCostBasis = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdCreateMaterialUsage':
                this.cmdCreateMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error':
                this.cmdCreateMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status':
                this.cmdUpdateMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId':
                this.cmdUpdateMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status':
                this.cmdUpdateMaterialUsageStatus = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId':
                this.cmdUpdateMaterialUsageProjectId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId':
                this.cmdUpdateMaterialUsageInventoryItemId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId':
                this.cmdUpdateMaterialUsageInventoryBalanceId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity':
                this.cmdUpdateMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription':
                this.cmdUpdateMaterialUsageUsageDescription = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn':
                this.cmdUpdateMaterialUsageConsumedOn = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis':
                this.cmdUpdateMaterialUsageUnitCostBasis = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage':
                this.cmdUpdateMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error':
                this.cmdUpdateMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status':
                this.cmdDeleteMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId':
                this.cmdDeleteMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage':
                this.cmdDeleteMaterialUsageOutput = value ?? null;
                break;
            case 'ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error':
                this.cmdDeleteMaterialUsageError = value ?? '';
                break;
            case 'ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status':
                this.qryInventoryBalancePickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryInventoryBalancePicker':
                this.qryInventoryBalancePickerData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.qryInventoryItemPicker.status':
                this.qryInventoryItemPickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryInventoryItemPicker':
                this.qryInventoryItemPickerData = value ?? [];
                break;
            case 'ui.materialUsageCatalogue.action.qryProjectPicker.status':
                this.qryProjectPickerState = value ?? 'idle';
                break;
            case 'ui.materialUsageCatalogue.data.qryProjectPicker':
                this.qryProjectPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/materialUsageCatalogue(?:\/([^/]+))?\/?$/);
        const rawProjectProjectId = match && match[1] ? match[1] : '';
        let projectProjectId = '';
        if (rawProjectProjectId) {
            try {
                projectProjectId = decodeURIComponent(rawProjectProjectId);
            }
            catch {
                projectProjectId = rawProjectProjectId;
            }
        }
        if (projectProjectId) {
            if (!this.cmdCreateMaterialUsageProjectProjectId) {
                this.cmdCreateMaterialUsageProjectProjectId = projectProjectId;
                setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId', projectProjectId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListMaterialUsage (query) — route buildFlowFsm.materialUsageCatalogue.qryListMaterialUsage; inputs: (none); writes ui.materialUsageCatalogue.data.qryListMaterialUsage; status ui.materialUsageCatalogue.action.qryListMaterialUsage.status */
    async loadQryListMaterialUsage() {
        this.syncRouteParams();
        this.qryListMaterialUsageState = 'loading';
        setState('ui.materialUsageCatalogue.action.qryListMaterialUsage.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListMaterialUsageRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListMaterialUsageData = data;
            setState('ui.materialUsageCatalogue.data.qryListMaterialUsage', data);
            this.qryListMaterialUsageState = 'success';
            setState('ui.materialUsageCatalogue.action.qryListMaterialUsage.status', 'success');
        }
        else {
            this.qryListMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.qryListMaterialUsage.status', 'error');
            if (response.error) {
                console.error('qryListMaterialUsage failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListMaterialUsage — bind UI events here */
    handleQryListMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListMaterialUsage();
    }
    /** action cmdCreateMaterialUsage (command) — route buildFlowFsm.materialUsageCatalogue.cmdCreateMaterialUsage; inputs: inventoryBalanceInventoryBalanceId, inventoryItemInventoryItemId, projectProjectId, quantity, usageDescription, consumedOn, unitCostBasis; writes ui.materialUsageCatalogue.output.cmdCreateMaterialUsage; status ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status; feedback keys action.cmdCreateMaterialUsage.success / action.cmdCreateMaterialUsage.error */
    async cmdCreateMaterialUsage() {
        this.syncRouteParams();
        if (!this.cmdCreateMaterialUsageProjectProjectId) {
            this.cmdCreateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId) {
            this.cmdCreateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdCreateMaterialUsageInventoryItemInventoryItemId) {
            this.cmdCreateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdCreateMaterialUsageState = 'loading';
        setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'loading');
        this.cmdCreateMaterialUsageError = '';
        setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error', '');
        const quantityNum = Number(this.cmdCreateMaterialUsageQuantity);
        const unitCostBasisNum = Number(this.cmdCreateMaterialUsageUnitCostBasis);
        const params = {
            inventoryBalanceInventoryBalanceId: this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId,
            inventoryItemInventoryItemId: this.cmdCreateMaterialUsageInventoryItemInventoryItemId,
            projectProjectId: this.cmdCreateMaterialUsageProjectProjectId,
            quantity: Number.isNaN(quantityNum) ? 0 : quantityNum,
            usageDescription: this.cmdCreateMaterialUsageUsageDescription,
            consumedOn: this.cmdCreateMaterialUsageConsumedOn,
            unitCostBasis: Number.isNaN(unitCostBasisNum) ? 0 : unitCostBasisNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateMaterialUsageRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateMaterialUsage.error');
            this.cmdCreateMaterialUsageError = errMsg;
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.error', errMsg);
            this.cmdCreateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateMaterialUsageOutput = data;
        setState('ui.materialUsageCatalogue.output.cmdCreateMaterialUsage', data);
        try {
            await this.loadQryListMaterialUsage();
            if (this.qryListMaterialUsageState === 'error') {
                this.cmdCreateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateMaterialUsage refresh failed', refreshError);
            this.cmdCreateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryBalancePicker();
            if (this.qryInventoryBalancePickerState === 'error') {
                this.cmdCreateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateMaterialUsage refresh failed', refreshError);
            this.cmdCreateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryItemPicker();
            if (this.qryInventoryItemPickerState === 'error') {
                this.cmdCreateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateMaterialUsage refresh failed', refreshError);
            this.cmdCreateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryProjectPicker();
            if (this.qryProjectPickerState === 'error') {
                this.cmdCreateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateMaterialUsage refresh failed', refreshError);
            this.cmdCreateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId', '');
        this.cmdCreateMaterialUsageInventoryItemInventoryItemId = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId', '');
        this.cmdCreateMaterialUsageQuantity = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity', '');
        this.cmdCreateMaterialUsageUsageDescription = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription', '');
        this.cmdCreateMaterialUsageConsumedOn = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn', '');
        this.cmdCreateMaterialUsageUnitCostBasis = '';
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis', '');
        this.cmdCreateMaterialUsageState = 'success';
        setState('ui.materialUsageCatalogue.action.cmdCreateMaterialUsage.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateMaterialUsage — bind UI events here */
    handleCmdCreateMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateMaterialUsage();
        });
    }
    /** action cmdUpdateMaterialUsage (command) — route buildFlowFsm.materialUsageCatalogue.cmdUpdateMaterialUsage; inputs: materialUsageId, status, projectId, inventoryItemId, inventoryBalanceId, quantity, usageDescription, consumedOn, unitCostBasis; writes ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage; status ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status; feedback keys action.cmdUpdateMaterialUsage.success / action.cmdUpdateMaterialUsage.error */
    async cmdUpdateMaterialUsage() {
        this.syncRouteParams();
        if (!this.cmdUpdateMaterialUsageMaterialUsageId) {
            this.cmdUpdateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateMaterialUsageProjectId) {
            this.cmdUpdateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateMaterialUsageInventoryItemId) {
            this.cmdUpdateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateMaterialUsageInventoryBalanceId) {
            this.cmdUpdateMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateMaterialUsageState = 'loading';
        setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'loading');
        this.cmdUpdateMaterialUsageError = '';
        setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error', '');
        const quantityNum = Number(this.cmdUpdateMaterialUsageQuantity);
        const unitCostBasisNum = Number(this.cmdUpdateMaterialUsageUnitCostBasis);
        const params = {
            materialUsageId: this.cmdUpdateMaterialUsageMaterialUsageId,
            status: this.cmdUpdateMaterialUsageStatus,
            projectId: this.cmdUpdateMaterialUsageProjectId,
            inventoryItemId: this.cmdUpdateMaterialUsageInventoryItemId,
            inventoryBalanceId: this.cmdUpdateMaterialUsageInventoryBalanceId,
            quantity: Number.isNaN(quantityNum) ? 0 : quantityNum,
            usageDescription: this.cmdUpdateMaterialUsageUsageDescription,
            consumedOn: this.cmdUpdateMaterialUsageConsumedOn,
            unitCostBasis: Number.isNaN(unitCostBasisNum) ? 0 : unitCostBasisNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateMaterialUsageRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateMaterialUsage.error');
            this.cmdUpdateMaterialUsageError = errMsg;
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.error', errMsg);
            this.cmdUpdateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateMaterialUsageOutput = data;
        setState('ui.materialUsageCatalogue.output.cmdUpdateMaterialUsage', data);
        try {
            await this.loadQryListMaterialUsage();
            if (this.qryListMaterialUsageState === 'error') {
                this.cmdUpdateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateMaterialUsage refresh failed', refreshError);
            this.cmdUpdateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryBalancePicker();
            if (this.qryInventoryBalancePickerState === 'error') {
                this.cmdUpdateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateMaterialUsage refresh failed', refreshError);
            this.cmdUpdateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryItemPicker();
            if (this.qryInventoryItemPickerState === 'error') {
                this.cmdUpdateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateMaterialUsage refresh failed', refreshError);
            this.cmdUpdateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryProjectPicker();
            if (this.qryProjectPickerState === 'error') {
                this.cmdUpdateMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateMaterialUsage refresh failed', refreshError);
            this.cmdUpdateMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateMaterialUsageMaterialUsageId = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId', '');
        this.cmdUpdateMaterialUsageStatus = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', '');
        this.cmdUpdateMaterialUsageProjectId = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId', '');
        this.cmdUpdateMaterialUsageInventoryItemId = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId', '');
        this.cmdUpdateMaterialUsageInventoryBalanceId = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId', '');
        this.cmdUpdateMaterialUsageQuantity = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', '');
        this.cmdUpdateMaterialUsageUsageDescription = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', '');
        this.cmdUpdateMaterialUsageConsumedOn = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', '');
        this.cmdUpdateMaterialUsageUnitCostBasis = '';
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', '');
        this.cmdUpdateMaterialUsageState = 'success';
        setState('ui.materialUsageCatalogue.action.cmdUpdateMaterialUsage.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateMaterialUsage — bind UI events here */
    handleCmdUpdateMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateMaterialUsage();
        });
    }
    /** action cmdDeleteMaterialUsage (command) — route buildFlowFsm.materialUsageCatalogue.cmdDeleteMaterialUsage; inputs: materialUsageId; writes ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage; status ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status; feedback keys action.cmdDeleteMaterialUsage.success / action.cmdDeleteMaterialUsage.error */
    async cmdDeleteMaterialUsage() {
        this.syncRouteParams();
        if (!this.cmdDeleteMaterialUsageMaterialUsageId) {
            this.cmdDeleteMaterialUsageState = 'idle';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteMaterialUsageState = 'loading';
        setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'loading');
        this.cmdDeleteMaterialUsageError = '';
        setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error', '');
        const params = {
            materialUsageId: this.cmdDeleteMaterialUsageMaterialUsageId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteMaterialUsageRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteMaterialUsage.error');
            this.cmdDeleteMaterialUsageError = errMsg;
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.error', errMsg);
            this.cmdDeleteMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteMaterialUsageOutput = data;
        setState('ui.materialUsageCatalogue.output.cmdDeleteMaterialUsage', data);
        try {
            await this.loadQryListMaterialUsage();
            if (this.qryListMaterialUsageState === 'error') {
                this.cmdDeleteMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteMaterialUsage refresh failed', refreshError);
            this.cmdDeleteMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryBalancePicker();
            if (this.qryInventoryBalancePickerState === 'error') {
                this.cmdDeleteMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteMaterialUsage refresh failed', refreshError);
            this.cmdDeleteMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryInventoryItemPicker();
            if (this.qryInventoryItemPickerState === 'error') {
                this.cmdDeleteMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteMaterialUsage refresh failed', refreshError);
            this.cmdDeleteMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryProjectPicker();
            if (this.qryProjectPickerState === 'error') {
                this.cmdDeleteMaterialUsageState = 'error';
                setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteMaterialUsage refresh failed', refreshError);
            this.cmdDeleteMaterialUsageState = 'error';
            setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteMaterialUsageMaterialUsageId = '';
        setState('ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId', '');
        this.cmdDeleteMaterialUsageState = 'success';
        setState('ui.materialUsageCatalogue.action.cmdDeleteMaterialUsage.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteMaterialUsage — bind UI events here */
    handleCmdDeleteMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteMaterialUsage();
        });
    }
    /** action qryInventoryBalancePicker (query) — route buildFlowFsm.materialUsageCatalogue.qryInventoryBalancePicker; inputs: (none); writes ui.materialUsageCatalogue.data.qryInventoryBalancePicker; status ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status */
    async loadQryInventoryBalancePicker() {
        this.syncRouteParams();
        this.qryInventoryBalancePickerState = 'loading';
        setState('ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryInventoryBalancePickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryInventoryBalancePickerData = data;
            setState('ui.materialUsageCatalogue.data.qryInventoryBalancePicker', data);
            this.qryInventoryBalancePickerState = 'success';
            setState('ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status', 'success');
        }
        else {
            this.qryInventoryBalancePickerState = 'error';
            setState('ui.materialUsageCatalogue.action.qryInventoryBalancePicker.status', 'error');
            if (response.error) {
                console.error('qryInventoryBalancePicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInventoryBalancePicker — bind UI events here */
    handleQryInventoryBalancePickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInventoryBalancePicker();
    }
    /** action qryInventoryItemPicker (query) — route buildFlowFsm.materialUsageCatalogue.qryInventoryItemPicker; inputs: (none); writes ui.materialUsageCatalogue.data.qryInventoryItemPicker; status ui.materialUsageCatalogue.action.qryInventoryItemPicker.status */
    async loadQryInventoryItemPicker() {
        this.syncRouteParams();
        this.qryInventoryItemPickerState = 'loading';
        setState('ui.materialUsageCatalogue.action.qryInventoryItemPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryInventoryItemPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryInventoryItemPickerData = data;
            setState('ui.materialUsageCatalogue.data.qryInventoryItemPicker', data);
            this.qryInventoryItemPickerState = 'success';
            setState('ui.materialUsageCatalogue.action.qryInventoryItemPicker.status', 'success');
        }
        else {
            this.qryInventoryItemPickerState = 'error';
            setState('ui.materialUsageCatalogue.action.qryInventoryItemPicker.status', 'error');
            if (response.error) {
                console.error('qryInventoryItemPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInventoryItemPicker — bind UI events here */
    handleQryInventoryItemPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInventoryItemPicker();
    }
    /** action qryProjectPicker (query) — route buildFlowFsm.materialUsageCatalogue.qryProjectPicker; inputs: (none); writes ui.materialUsageCatalogue.data.qryProjectPicker; status ui.materialUsageCatalogue.action.qryProjectPicker.status */
    async loadQryProjectPicker() {
        this.syncRouteParams();
        this.qryProjectPickerState = 'loading';
        setState('ui.materialUsageCatalogue.action.qryProjectPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryProjectPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryProjectPickerData = data;
            setState('ui.materialUsageCatalogue.data.qryProjectPicker', data);
            this.qryProjectPickerState = 'success';
            setState('ui.materialUsageCatalogue.action.qryProjectPicker.status', 'success');
        }
        else {
            this.qryProjectPickerState = 'error';
            setState('ui.materialUsageCatalogue.action.qryProjectPicker.status', 'error');
            if (response.error) {
                console.error('qryProjectPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryProjectPicker — bind UI events here */
    handleQryProjectPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryProjectPicker();
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId */
    setCmdCreateMaterialUsageInventoryBalanceInventoryBalanceId(value) {
        this.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryBalanceInventoryBalanceId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId — bind UI events here */
    handleCmdCreateMaterialUsageInventoryBalanceInventoryBalanceIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageInventoryBalanceInventoryBalanceId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId */
    setCmdCreateMaterialUsageInventoryItemInventoryItemId(value) {
        this.cmdCreateMaterialUsageInventoryItemInventoryItemId = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.inventoryItemInventoryItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageInventoryItemInventoryItemId — bind UI events here */
    handleCmdCreateMaterialUsageInventoryItemInventoryItemIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageInventoryItemInventoryItemId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId */
    setCmdCreateMaterialUsageProjectProjectId(value) {
        this.cmdCreateMaterialUsageProjectProjectId = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.projectProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageProjectProjectId — bind UI events here */
    handleCmdCreateMaterialUsageProjectProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageProjectProjectId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity */
    setCmdCreateMaterialUsageQuantity(value) {
        this.cmdCreateMaterialUsageQuantity = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageQuantity — bind UI events here */
    handleCmdCreateMaterialUsageQuantityChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageQuantity(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription */
    setCmdCreateMaterialUsageUsageDescription(value) {
        this.cmdCreateMaterialUsageUsageDescription = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.usageDescription', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageUsageDescription — bind UI events here */
    handleCmdCreateMaterialUsageUsageDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageUsageDescription(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn */
    setCmdCreateMaterialUsageConsumedOn(value) {
        this.cmdCreateMaterialUsageConsumedOn = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.consumedOn', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageConsumedOn — bind UI events here */
    handleCmdCreateMaterialUsageConsumedOnChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageConsumedOn(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis */
    setCmdCreateMaterialUsageUnitCostBasis(value) {
        this.cmdCreateMaterialUsageUnitCostBasis = value;
        setState('ui.materialUsageCatalogue.input.cmdCreateMaterialUsage.unitCostBasis', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateMaterialUsageUnitCostBasis — bind UI events here */
    handleCmdCreateMaterialUsageUnitCostBasisChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateMaterialUsageUnitCostBasis(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId */
    setCmdUpdateMaterialUsageMaterialUsageId(value) {
        this.cmdUpdateMaterialUsageMaterialUsageId = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.materialUsageId', value);
        const collection = getState('ui.materialUsageCatalogue.data.qryListMaterialUsage') ?? this.qryListMaterialUsageData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.materialUsageId) === String(value));
            if (item) {
                this.cmdUpdateMaterialUsageStatus = item.status;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', item.status);
                this.cmdUpdateMaterialUsageQuantity = String(item.quantity);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', String(item.quantity));
                this.cmdUpdateMaterialUsageUsageDescription = item.usageDescription;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', item.usageDescription);
                this.cmdUpdateMaterialUsageConsumedOn = item.consumedOn;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', item.consumedOn);
                this.cmdUpdateMaterialUsageUnitCostBasis = String(item.unitCostBasis);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', String(item.unitCostBasis));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageMaterialUsageId — bind UI events here */
    handleCmdUpdateMaterialUsageMaterialUsageIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageMaterialUsageId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status */
    setCmdUpdateMaterialUsageStatus(value) {
        this.cmdUpdateMaterialUsageStatus = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageStatus — bind UI events here */
    handleCmdUpdateMaterialUsageStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageStatus(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId */
    setCmdUpdateMaterialUsageProjectId(value) {
        this.cmdUpdateMaterialUsageProjectId = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.projectId', value);
        const collection = getState('ui.materialUsageCatalogue.data.qryListMaterialUsage') ?? this.qryListMaterialUsageData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.projectId) === String(value));
            if (item) {
                this.cmdUpdateMaterialUsageStatus = item.status;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', item.status);
                this.cmdUpdateMaterialUsageQuantity = String(item.quantity);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', String(item.quantity));
                this.cmdUpdateMaterialUsageUsageDescription = item.usageDescription;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', item.usageDescription);
                this.cmdUpdateMaterialUsageConsumedOn = item.consumedOn;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', item.consumedOn);
                this.cmdUpdateMaterialUsageUnitCostBasis = String(item.unitCostBasis);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', String(item.unitCostBasis));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageProjectId — bind UI events here */
    handleCmdUpdateMaterialUsageProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageProjectId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId */
    setCmdUpdateMaterialUsageInventoryItemId(value) {
        this.cmdUpdateMaterialUsageInventoryItemId = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryItemId', value);
        const collection = getState('ui.materialUsageCatalogue.data.qryListMaterialUsage') ?? this.qryListMaterialUsageData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.inventoryItemId) === String(value));
            if (item) {
                this.cmdUpdateMaterialUsageStatus = item.status;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', item.status);
                this.cmdUpdateMaterialUsageQuantity = String(item.quantity);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', String(item.quantity));
                this.cmdUpdateMaterialUsageUsageDescription = item.usageDescription;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', item.usageDescription);
                this.cmdUpdateMaterialUsageConsumedOn = item.consumedOn;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', item.consumedOn);
                this.cmdUpdateMaterialUsageUnitCostBasis = String(item.unitCostBasis);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', String(item.unitCostBasis));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageInventoryItemId — bind UI events here */
    handleCmdUpdateMaterialUsageInventoryItemIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageInventoryItemId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId */
    setCmdUpdateMaterialUsageInventoryBalanceId(value) {
        this.cmdUpdateMaterialUsageInventoryBalanceId = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.inventoryBalanceId', value);
        const collection = getState('ui.materialUsageCatalogue.data.qryListMaterialUsage') ?? this.qryListMaterialUsageData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.inventoryBalanceId) === String(value));
            if (item) {
                this.cmdUpdateMaterialUsageStatus = item.status;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.status', item.status);
                this.cmdUpdateMaterialUsageQuantity = String(item.quantity);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', String(item.quantity));
                this.cmdUpdateMaterialUsageUsageDescription = item.usageDescription;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', item.usageDescription);
                this.cmdUpdateMaterialUsageConsumedOn = item.consumedOn;
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', item.consumedOn);
                this.cmdUpdateMaterialUsageUnitCostBasis = String(item.unitCostBasis);
                setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', String(item.unitCostBasis));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageInventoryBalanceId — bind UI events here */
    handleCmdUpdateMaterialUsageInventoryBalanceIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageInventoryBalanceId(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity */
    setCmdUpdateMaterialUsageQuantity(value) {
        this.cmdUpdateMaterialUsageQuantity = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageQuantity — bind UI events here */
    handleCmdUpdateMaterialUsageQuantityChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageQuantity(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription */
    setCmdUpdateMaterialUsageUsageDescription(value) {
        this.cmdUpdateMaterialUsageUsageDescription = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.usageDescription', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageUsageDescription — bind UI events here */
    handleCmdUpdateMaterialUsageUsageDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageUsageDescription(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn */
    setCmdUpdateMaterialUsageConsumedOn(value) {
        this.cmdUpdateMaterialUsageConsumedOn = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.consumedOn', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageConsumedOn — bind UI events here */
    handleCmdUpdateMaterialUsageConsumedOnChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageConsumedOn(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis */
    setCmdUpdateMaterialUsageUnitCostBasis(value) {
        this.cmdUpdateMaterialUsageUnitCostBasis = value;
        setState('ui.materialUsageCatalogue.input.cmdUpdateMaterialUsage.unitCostBasis', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateMaterialUsageUnitCostBasis — bind UI events here */
    handleCmdUpdateMaterialUsageUnitCostBasisChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateMaterialUsageUnitCostBasis(value);
    }
    /** setter for state ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId */
    setCmdDeleteMaterialUsageMaterialUsageId(value) {
        this.cmdDeleteMaterialUsageMaterialUsageId = value;
        setState('ui.materialUsageCatalogue.input.cmdDeleteMaterialUsage.materialUsageId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteMaterialUsageMaterialUsageId — bind UI events here */
    handleCmdDeleteMaterialUsageMaterialUsageIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteMaterialUsageMaterialUsageId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryListMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryListMaterialUsageData", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageInventoryBalanceInventoryBalanceId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageInventoryItemInventoryItemId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageProjectProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageQuantity", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageUsageDescription", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageConsumedOn", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageUnitCostBasis", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageOutput", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdCreateMaterialUsageError", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageMaterialUsageId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageStatus", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageInventoryItemId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageInventoryBalanceId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageQuantity", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageUsageDescription", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageConsumedOn", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageUnitCostBasis", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageOutput", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdUpdateMaterialUsageError", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdDeleteMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdDeleteMaterialUsageMaterialUsageId", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdDeleteMaterialUsageOutput", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "cmdDeleteMaterialUsageError", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryInventoryBalancePickerState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryInventoryBalancePickerData", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryInventoryItemPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryInventoryItemPickerData", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryProjectPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmMaterialUsageCatalogueBase.prototype, "qryProjectPickerData", void 0);
