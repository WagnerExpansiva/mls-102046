/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/changeOrderDecisionCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListChangeOrderDecisionRoute, cmdCreateChangeOrderDecisionRoute, cmdUpdateChangeOrderDecisionRoute, cmdDeleteChangeOrderDecisionRoute, qryChangeOrderPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/changeOrderDecisionCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.changeOrderDecisionCatalogue.recordList.title': 'Localizar decisões',
    'organism.changeOrderDecisionCatalogue.qryListChangeOrderDecision.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrderDecisionId.label': 'Change Order Decision Id',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrder.label': 'Change Order',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.action.cmdUpdateChangeOrderDecision': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.action.cmdDeleteChangeOrderDecision': 'Excluir Decisão sobre ordem de mudança',
    'section.changeOrderDecisionCatalogue.recordForm.title': 'Criar ou corrigir decisão',
    'organism.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.action.cmdCreateChangeOrderDecision': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'action.cmdCreateChangeOrderDecision.success': 'Criar Decisão sobre ordem de mudança: OK',
    'action.cmdCreateChangeOrderDecision.error': 'Criar Decisão sobre ordem de mudança: falhou',
    'action.cmdUpdateChangeOrderDecision.success': 'Atualizar Decisão sobre ordem de mudança: OK',
    'action.cmdUpdateChangeOrderDecision.error': 'Atualizar Decisão sobre ordem de mudança: falhou',
    'action.cmdDeleteChangeOrderDecision.success': 'Excluir Decisão sobre ordem de mudança: OK',
    'action.cmdDeleteChangeOrderDecision.error': 'Excluir Decisão sobre ordem de mudança: falhou',
    'section.changeOrderDecisionCatalogue.decisionWorkbench.title': 'Decisões sobre ordens de mudança',
    'section.changeOrderDecisionCatalogue.decisionCreation.title': 'Registrar decisão',
    'section.changeOrderDecisionCatalogue.newDecision.title': 'Registrar decisão',
};
const message_pt_br = {
    'section.changeOrderDecisionCatalogue.recordList.title': 'Localizar decisões',
    'organism.changeOrderDecisionCatalogue.qryListChangeOrderDecision.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrderDecisionId.label': 'Change Order Decision Id',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrder.label': 'Change Order',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.action.cmdUpdateChangeOrderDecision': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.action.cmdDeleteChangeOrderDecision': 'Excluir Decisão sobre ordem de mudança',
    'section.changeOrderDecisionCatalogue.recordForm.title': 'Criar ou corrigir decisão',
    'organism.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.action.cmdCreateChangeOrderDecision': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'action.cmdCreateChangeOrderDecision.success': 'Criar Decisão sobre ordem de mudança: OK',
    'action.cmdCreateChangeOrderDecision.error': 'Criar Decisão sobre ordem de mudança: falhou',
    'action.cmdUpdateChangeOrderDecision.success': 'Atualizar Decisão sobre ordem de mudança: OK',
    'action.cmdUpdateChangeOrderDecision.error': 'Atualizar Decisão sobre ordem de mudança: falhou',
    'action.cmdDeleteChangeOrderDecision.success': 'Excluir Decisão sobre ordem de mudança: OK',
    'action.cmdDeleteChangeOrderDecision.error': 'Excluir Decisão sobre ordem de mudança: falhou',
    'section.changeOrderDecisionCatalogue.decisionWorkbench.title': 'Decisões sobre ordens de mudança',
    'section.changeOrderDecisionCatalogue.decisionCreation.title': 'Registrar decisão',
    'section.changeOrderDecisionCatalogue.newDecision.title': 'Registrar decisão',
};
const message_en = {
    'section.changeOrderDecisionCatalogue.recordList.title': 'Localizar decisões',
    'organism.changeOrderDecisionCatalogue.qryListChangeOrderDecision.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrderDecisionId.label': 'Change Order Decision Id',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrder.label': 'Change Order',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.action.cmdUpdateChangeOrderDecision': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.action.cmdDeleteChangeOrderDecision': 'Excluir Decisão sobre ordem de mudança',
    'section.changeOrderDecisionCatalogue.recordForm.title': 'Criar ou corrigir decisão',
    'organism.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.action.cmdCreateChangeOrderDecision': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'action.cmdCreateChangeOrderDecision.success': 'Criar Decisão sobre ordem de mudança: OK',
    'action.cmdCreateChangeOrderDecision.error': 'Criar Decisão sobre ordem de mudança: falhou',
    'action.cmdUpdateChangeOrderDecision.success': 'Atualizar Decisão sobre ordem de mudança: OK',
    'action.cmdUpdateChangeOrderDecision.error': 'Atualizar Decisão sobre ordem de mudança: falhou',
    'action.cmdDeleteChangeOrderDecision.success': 'Excluir Decisão sobre ordem de mudança: OK',
    'action.cmdDeleteChangeOrderDecision.error': 'Excluir Decisão sobre ordem de mudança: falhou',
    'section.changeOrderDecisionCatalogue.decisionWorkbench.title': 'Decisões sobre ordens de mudança',
    'section.changeOrderDecisionCatalogue.decisionCreation.title': 'Registrar decisão',
    'section.changeOrderDecisionCatalogue.newDecision.title': 'Registrar decisão',
};
const message_es = {
    'section.changeOrderDecisionCatalogue.recordList.title': 'Localizar decisões',
    'organism.changeOrderDecisionCatalogue.qryListChangeOrderDecision.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.title': 'Listar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrderDecisionId.label': 'Change Order Decision Id',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.changeOrder.label': 'Change Order',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.qryListChangeOrderDecision.list.column.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.title': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.action.cmdUpdateChangeOrderDecision': 'Atualizar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.title': 'Excluir Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision.form.action.cmdDeleteChangeOrderDecision': 'Excluir Decisão sobre ordem de mudança',
    'section.changeOrderDecisionCatalogue.recordForm.title': 'Criar ou corrigir decisão',
    'organism.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.title': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.action.cmdCreateChangeOrderDecision': 'Criar Decisão sobre ordem de mudança',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.madeByPlatformUser.label': 'Made By Platform User',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decision.label': 'Decision',
    'intent.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision.form.field.decidedAt.label': 'Decided At',
    'organism.changeOrderDecisionCatalogue.qryChangeOrderPicker.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.title': 'Listar Ordem de mudança',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.empty': 'Nenhum registro encontrado',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeOrderId.label': 'Change Order Id',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.clientRef.label': 'Client Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.projectRef.label': 'Project Ref',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.description.label': 'Description',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scopeImpact.label': 'Scope Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.changeAmount.label': 'Change Amount',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.submittedAt.label': 'Submitted At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.changeOrderDecisionCatalogue.qryChangeOrderPicker.list.column.status.label': 'Status',
    'action.cmdCreateChangeOrderDecision.success': 'Criar Decisão sobre ordem de mudança: OK',
    'action.cmdCreateChangeOrderDecision.error': 'Criar Decisão sobre ordem de mudança: falhou',
    'action.cmdUpdateChangeOrderDecision.success': 'Atualizar Decisão sobre ordem de mudança: OK',
    'action.cmdUpdateChangeOrderDecision.error': 'Atualizar Decisão sobre ordem de mudança: falhou',
    'action.cmdDeleteChangeOrderDecision.success': 'Excluir Decisão sobre ordem de mudança: OK',
    'action.cmdDeleteChangeOrderDecision.error': 'Excluir Decisão sobre ordem de mudança: falhou',
    'section.changeOrderDecisionCatalogue.decisionWorkbench.title': 'Decisões sobre ordens de mudança',
    'section.changeOrderDecisionCatalogue.decisionCreation.title': 'Registrar decisão',
    'section.changeOrderDecisionCatalogue.newDecision.title': 'Registrar decisão',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.changeOrderDecisionCatalogue.status',
    'ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status',
    'ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision',
    'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status',
    'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder',
    'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser',
    'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision',
    'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt',
    'ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision',
    'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error',
    'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status',
    'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId',
    'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder',
    'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser',
    'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision',
    'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt',
    'ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision',
    'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error',
    'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status',
    'ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId',
    'ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision',
    'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error',
    'ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status',
    'ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker',
];
export class BuildFlowFsmChangeOrderDecisionCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListChangeOrderDecisionState — actionStatus, values: idle|loading|success|error */
        this.qryListChangeOrderDecisionState = 'idle';
        /** state qryListChangeOrderDecisionData — queryResult, outputShape: array */
        this.qryListChangeOrderDecisionData = [];
        /** state cmdCreateChangeOrderDecisionState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateChangeOrderDecisionState = 'idle';
        /** state cmdCreateChangeOrderDecisionChangeOrder — input */
        this.cmdCreateChangeOrderDecisionChangeOrder = '';
        /** state cmdCreateChangeOrderDecisionMadeByPlatformUser — input */
        this.cmdCreateChangeOrderDecisionMadeByPlatformUser = '';
        /** state cmdCreateChangeOrderDecisionDecision — input */
        this.cmdCreateChangeOrderDecisionDecision = '';
        /** state cmdCreateChangeOrderDecisionDecidedAt — input */
        this.cmdCreateChangeOrderDecisionDecidedAt = '';
        /** state cmdCreateChangeOrderDecisionOutput — commandOutput */
        this.cmdCreateChangeOrderDecisionOutput = null;
        /** state cmdCreateChangeOrderDecisionError — actionError */
        this.cmdCreateChangeOrderDecisionError = '';
        /** state cmdUpdateChangeOrderDecisionState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateChangeOrderDecisionState = 'idle';
        /** state cmdUpdateChangeOrderDecisionChangeOrderDecisionId — input */
        this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId = '';
        /** state cmdUpdateChangeOrderDecisionChangeOrder — input */
        this.cmdUpdateChangeOrderDecisionChangeOrder = '';
        /** state cmdUpdateChangeOrderDecisionMadeByPlatformUser — input */
        this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = '';
        /** state cmdUpdateChangeOrderDecisionDecision — input */
        this.cmdUpdateChangeOrderDecisionDecision = '';
        /** state cmdUpdateChangeOrderDecisionDecidedAt — input */
        this.cmdUpdateChangeOrderDecisionDecidedAt = '';
        /** state cmdUpdateChangeOrderDecisionOutput — commandOutput */
        this.cmdUpdateChangeOrderDecisionOutput = null;
        /** state cmdUpdateChangeOrderDecisionError — actionError */
        this.cmdUpdateChangeOrderDecisionError = '';
        /** state cmdDeleteChangeOrderDecisionState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteChangeOrderDecisionState = 'idle';
        /** state cmdDeleteChangeOrderDecisionChangeOrderDecisionId — input */
        this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId = '';
        /** state cmdDeleteChangeOrderDecisionOutput — commandOutput */
        this.cmdDeleteChangeOrderDecisionOutput = null;
        /** state cmdDeleteChangeOrderDecisionError — actionError */
        this.cmdDeleteChangeOrderDecisionError = '';
        /** state qryChangeOrderPickerState — actionStatus, values: idle|loading|success|error */
        this.qryChangeOrderPickerState = 'idle';
        /** state qryChangeOrderPickerData — queryResult, outputShape: array */
        this.qryChangeOrderPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.changeOrderDecisionCatalogue.status', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status', 'idle');
        this.initStateValue('ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision', []);
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'idle');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision', null);
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'idle');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision', null);
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'idle');
        this.initStateValue('ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision', null);
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error', '');
        this.initStateValue('ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status', 'idle');
        this.initStateValue('ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker', []);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListChangeOrderDecision();
        void this.loadQryChangeOrderPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.changeOrderDecisionCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status':
                this.qryListChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision':
                this.qryListChangeOrderDecisionData = value ?? [];
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status':
                this.cmdCreateChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder':
                this.cmdCreateChangeOrderDecisionChangeOrder = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser':
                this.cmdCreateChangeOrderDecisionMadeByPlatformUser = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision':
                this.cmdCreateChangeOrderDecisionDecision = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt':
                this.cmdCreateChangeOrderDecisionDecidedAt = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision':
                this.cmdCreateChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error':
                this.cmdCreateChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status':
                this.cmdUpdateChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId':
                this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder':
                this.cmdUpdateChangeOrderDecisionChangeOrder = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser':
                this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision':
                this.cmdUpdateChangeOrderDecisionDecision = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt':
                this.cmdUpdateChangeOrderDecisionDecidedAt = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision':
                this.cmdUpdateChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error':
                this.cmdUpdateChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status':
                this.cmdDeleteChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId':
                this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision':
                this.cmdDeleteChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error':
                this.cmdDeleteChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status':
                this.qryChangeOrderPickerState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker':
                this.qryChangeOrderPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.changeOrderDecisionCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status':
                this.qryListChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision':
                this.qryListChangeOrderDecisionData = value ?? [];
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status':
                this.cmdCreateChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder':
                this.cmdCreateChangeOrderDecisionChangeOrder = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser':
                this.cmdCreateChangeOrderDecisionMadeByPlatformUser = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision':
                this.cmdCreateChangeOrderDecisionDecision = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt':
                this.cmdCreateChangeOrderDecisionDecidedAt = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision':
                this.cmdCreateChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error':
                this.cmdCreateChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status':
                this.cmdUpdateChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId':
                this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder':
                this.cmdUpdateChangeOrderDecisionChangeOrder = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser':
                this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision':
                this.cmdUpdateChangeOrderDecisionDecision = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt':
                this.cmdUpdateChangeOrderDecisionDecidedAt = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision':
                this.cmdUpdateChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error':
                this.cmdUpdateChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status':
                this.cmdDeleteChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId':
                this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision':
                this.cmdDeleteChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error':
                this.cmdDeleteChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status':
                this.qryChangeOrderPickerState = value ?? 'idle';
                break;
            case 'ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker':
                this.qryChangeOrderPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListChangeOrderDecision (query) — route buildFlowFsm.changeOrderDecisionCatalogue.qryListChangeOrderDecision; inputs: (none); writes ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision; status ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status */
    async loadQryListChangeOrderDecision() {
        this.qryListChangeOrderDecisionState = 'loading';
        setState('ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListChangeOrderDecisionRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListChangeOrderDecisionData = data;
            setState('ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision', data);
            this.qryListChangeOrderDecisionState = 'success';
            setState('ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status', 'success');
        }
        else {
            this.qryListChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.qryListChangeOrderDecision.status', 'error');
            if (response.error) {
                console.error('qryListChangeOrderDecision failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListChangeOrderDecision — bind UI events here */
    handleQryListChangeOrderDecisionClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListChangeOrderDecision();
    }
    /** action cmdCreateChangeOrderDecision (command) — route buildFlowFsm.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision; inputs: changeOrder, madeByPlatformUser, decision, decidedAt; writes ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision; status ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status; feedback keys action.cmdCreateChangeOrderDecision.success / action.cmdCreateChangeOrderDecision.error */
    async cmdCreateChangeOrderDecision() {
        if (!this.cmdCreateChangeOrderDecisionChangeOrder) {
            this.cmdCreateChangeOrderDecisionState = 'idle';
            setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdCreateChangeOrderDecisionState = 'loading';
        setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'loading');
        this.cmdCreateChangeOrderDecisionError = '';
        setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error', '');
        const params = {
            changeOrder: this.cmdCreateChangeOrderDecisionChangeOrder,
            madeByPlatformUser: this.cmdCreateChangeOrderDecisionMadeByPlatformUser,
            decision: this.cmdCreateChangeOrderDecisionDecision,
            decidedAt: this.cmdCreateChangeOrderDecisionDecidedAt,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateChangeOrderDecisionRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateChangeOrderDecision.error');
            this.cmdCreateChangeOrderDecisionError = errMsg;
            setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.error', errMsg);
            this.cmdCreateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateChangeOrderDecisionOutput = data;
        setState('ui.changeOrderDecisionCatalogue.output.cmdCreateChangeOrderDecision', data);
        try {
            await this.loadQryListChangeOrderDecision();
            if (this.qryListChangeOrderDecisionState === 'error') {
                this.cmdCreateChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateChangeOrderDecision refresh failed', refreshError);
            this.cmdCreateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdCreateChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateChangeOrderDecision refresh failed', refreshError);
            this.cmdCreateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateChangeOrderDecisionChangeOrder = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder', '');
        this.cmdCreateChangeOrderDecisionMadeByPlatformUser = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser', '');
        this.cmdCreateChangeOrderDecisionDecision = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision', '');
        this.cmdCreateChangeOrderDecisionDecidedAt = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt', '');
        this.cmdCreateChangeOrderDecisionState = 'success';
        setState('ui.changeOrderDecisionCatalogue.action.cmdCreateChangeOrderDecision.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateChangeOrderDecision — bind UI events here */
    handleCmdCreateChangeOrderDecisionClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateChangeOrderDecision();
        });
    }
    /** action cmdUpdateChangeOrderDecision (command) — route buildFlowFsm.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision; inputs: changeOrderDecisionId, changeOrder, madeByPlatformUser, decision, decidedAt; writes ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision; status ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status; feedback keys action.cmdUpdateChangeOrderDecision.success / action.cmdUpdateChangeOrderDecision.error */
    async cmdUpdateChangeOrderDecision() {
        if (!this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId) {
            this.cmdUpdateChangeOrderDecisionState = 'idle';
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateChangeOrderDecisionChangeOrder) {
            this.cmdUpdateChangeOrderDecisionState = 'idle';
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateChangeOrderDecisionState = 'loading';
        setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'loading');
        this.cmdUpdateChangeOrderDecisionError = '';
        setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error', '');
        const params = {
            changeOrderDecisionId: this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId,
            changeOrder: this.cmdUpdateChangeOrderDecisionChangeOrder,
            madeByPlatformUser: this.cmdUpdateChangeOrderDecisionMadeByPlatformUser,
            decision: this.cmdUpdateChangeOrderDecisionDecision,
            decidedAt: this.cmdUpdateChangeOrderDecisionDecidedAt,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateChangeOrderDecisionRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateChangeOrderDecision.error');
            this.cmdUpdateChangeOrderDecisionError = errMsg;
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.error', errMsg);
            this.cmdUpdateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateChangeOrderDecisionOutput = data;
        setState('ui.changeOrderDecisionCatalogue.output.cmdUpdateChangeOrderDecision', data);
        try {
            await this.loadQryListChangeOrderDecision();
            if (this.qryListChangeOrderDecisionState === 'error') {
                this.cmdUpdateChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateChangeOrderDecision refresh failed', refreshError);
            this.cmdUpdateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdUpdateChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateChangeOrderDecision refresh failed', refreshError);
            this.cmdUpdateChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId', '');
        this.cmdUpdateChangeOrderDecisionChangeOrder = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder', '');
        this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser', '');
        this.cmdUpdateChangeOrderDecisionDecision = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision', '');
        this.cmdUpdateChangeOrderDecisionDecidedAt = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt', '');
        this.cmdUpdateChangeOrderDecisionState = 'success';
        setState('ui.changeOrderDecisionCatalogue.action.cmdUpdateChangeOrderDecision.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateChangeOrderDecision — bind UI events here */
    handleCmdUpdateChangeOrderDecisionClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateChangeOrderDecision();
        });
    }
    /** action cmdDeleteChangeOrderDecision (command) — route buildFlowFsm.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision; inputs: changeOrderDecisionId; writes ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision; status ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status; feedback keys action.cmdDeleteChangeOrderDecision.success / action.cmdDeleteChangeOrderDecision.error */
    async cmdDeleteChangeOrderDecision() {
        if (!this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId) {
            this.cmdDeleteChangeOrderDecisionState = 'idle';
            setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteChangeOrderDecisionState = 'loading';
        setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'loading');
        this.cmdDeleteChangeOrderDecisionError = '';
        setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error', '');
        const params = {
            changeOrderDecisionId: this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteChangeOrderDecisionRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteChangeOrderDecision.error');
            this.cmdDeleteChangeOrderDecisionError = errMsg;
            setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.error', errMsg);
            this.cmdDeleteChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteChangeOrderDecisionOutput = data;
        setState('ui.changeOrderDecisionCatalogue.output.cmdDeleteChangeOrderDecision', data);
        try {
            await this.loadQryListChangeOrderDecision();
            if (this.qryListChangeOrderDecisionState === 'error') {
                this.cmdDeleteChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteChangeOrderDecision refresh failed', refreshError);
            this.cmdDeleteChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryChangeOrderPicker();
            if (this.qryChangeOrderPickerState === 'error') {
                this.cmdDeleteChangeOrderDecisionState = 'error';
                setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteChangeOrderDecision refresh failed', refreshError);
            this.cmdDeleteChangeOrderDecisionState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId = '';
        setState('ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId', '');
        this.cmdDeleteChangeOrderDecisionState = 'success';
        setState('ui.changeOrderDecisionCatalogue.action.cmdDeleteChangeOrderDecision.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteChangeOrderDecision — bind UI events here */
    handleCmdDeleteChangeOrderDecisionClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteChangeOrderDecision();
        });
    }
    /** action qryChangeOrderPicker (query) — route buildFlowFsm.changeOrderDecisionCatalogue.qryChangeOrderPicker; inputs: (none); writes ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker; status ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status */
    async loadQryChangeOrderPicker() {
        this.qryChangeOrderPickerState = 'loading';
        setState('ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryChangeOrderPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryChangeOrderPickerData = data;
            setState('ui.changeOrderDecisionCatalogue.data.qryChangeOrderPicker', data);
            this.qryChangeOrderPickerState = 'success';
            setState('ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status', 'success');
        }
        else {
            this.qryChangeOrderPickerState = 'error';
            setState('ui.changeOrderDecisionCatalogue.action.qryChangeOrderPicker.status', 'error');
            if (response.error) {
                console.error('qryChangeOrderPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryChangeOrderPicker — bind UI events here */
    handleQryChangeOrderPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryChangeOrderPicker();
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder */
    setCmdCreateChangeOrderDecisionChangeOrder(value) {
        this.cmdCreateChangeOrderDecisionChangeOrder = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.changeOrder', value);
        const collection = getState('ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision') ?? this.qryListChangeOrderDecisionData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.changeOrder) === String(value));
            if (item) {
                this.cmdCreateChangeOrderDecisionMadeByPlatformUser = item.madeByPlatformUser;
                setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser', item.madeByPlatformUser);
                this.cmdCreateChangeOrderDecisionDecision = item.decision;
                setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision', item.decision);
                this.cmdCreateChangeOrderDecisionDecidedAt = item.decidedAt;
                setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt', item.decidedAt);
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderDecisionChangeOrder — bind UI events here */
    handleCmdCreateChangeOrderDecisionChangeOrderChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateChangeOrderDecisionChangeOrder(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser */
    setCmdCreateChangeOrderDecisionMadeByPlatformUser(value) {
        this.cmdCreateChangeOrderDecisionMadeByPlatformUser = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.madeByPlatformUser', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderDecisionMadeByPlatformUser — bind UI events here */
    handleCmdCreateChangeOrderDecisionMadeByPlatformUserChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateChangeOrderDecisionMadeByPlatformUser(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision */
    setCmdCreateChangeOrderDecisionDecision(value) {
        this.cmdCreateChangeOrderDecisionDecision = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decision', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderDecisionDecision — bind UI events here */
    handleCmdCreateChangeOrderDecisionDecisionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateChangeOrderDecisionDecision(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt */
    setCmdCreateChangeOrderDecisionDecidedAt(value) {
        this.cmdCreateChangeOrderDecisionDecidedAt = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdCreateChangeOrderDecision.decidedAt', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderDecisionDecidedAt — bind UI events here */
    handleCmdCreateChangeOrderDecisionDecidedAtChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateChangeOrderDecisionDecidedAt(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId */
    setCmdUpdateChangeOrderDecisionChangeOrderDecisionId(value) {
        this.cmdUpdateChangeOrderDecisionChangeOrderDecisionId = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrderDecisionId', value);
        const collection = getState('ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision') ?? this.qryListChangeOrderDecisionData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.changeOrderDecisionId) === String(value));
            if (item) {
                this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = item.madeByPlatformUser;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser', item.madeByPlatformUser);
                this.cmdUpdateChangeOrderDecisionDecision = item.decision;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision', item.decision);
                this.cmdUpdateChangeOrderDecisionDecidedAt = item.decidedAt;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt', item.decidedAt);
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDecisionChangeOrderDecisionId — bind UI events here */
    handleCmdUpdateChangeOrderDecisionChangeOrderDecisionIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateChangeOrderDecisionChangeOrderDecisionId(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder */
    setCmdUpdateChangeOrderDecisionChangeOrder(value) {
        this.cmdUpdateChangeOrderDecisionChangeOrder = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.changeOrder', value);
        const collection = getState('ui.changeOrderDecisionCatalogue.data.qryListChangeOrderDecision') ?? this.qryListChangeOrderDecisionData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.changeOrder) === String(value));
            if (item) {
                this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = item.madeByPlatformUser;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser', item.madeByPlatformUser);
                this.cmdUpdateChangeOrderDecisionDecision = item.decision;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision', item.decision);
                this.cmdUpdateChangeOrderDecisionDecidedAt = item.decidedAt;
                setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt', item.decidedAt);
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDecisionChangeOrder — bind UI events here */
    handleCmdUpdateChangeOrderDecisionChangeOrderChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateChangeOrderDecisionChangeOrder(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser */
    setCmdUpdateChangeOrderDecisionMadeByPlatformUser(value) {
        this.cmdUpdateChangeOrderDecisionMadeByPlatformUser = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.madeByPlatformUser', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDecisionMadeByPlatformUser — bind UI events here */
    handleCmdUpdateChangeOrderDecisionMadeByPlatformUserChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateChangeOrderDecisionMadeByPlatformUser(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision */
    setCmdUpdateChangeOrderDecisionDecision(value) {
        this.cmdUpdateChangeOrderDecisionDecision = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decision', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDecisionDecision — bind UI events here */
    handleCmdUpdateChangeOrderDecisionDecisionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateChangeOrderDecisionDecision(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt */
    setCmdUpdateChangeOrderDecisionDecidedAt(value) {
        this.cmdUpdateChangeOrderDecisionDecidedAt = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdUpdateChangeOrderDecision.decidedAt', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDecisionDecidedAt — bind UI events here */
    handleCmdUpdateChangeOrderDecisionDecidedAtChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateChangeOrderDecisionDecidedAt(value);
    }
    /** setter for state ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId */
    setCmdDeleteChangeOrderDecisionChangeOrderDecisionId(value) {
        this.cmdDeleteChangeOrderDecisionChangeOrderDecisionId = value;
        setState('ui.changeOrderDecisionCatalogue.input.cmdDeleteChangeOrderDecision.changeOrderDecisionId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteChangeOrderDecisionChangeOrderDecisionId — bind UI events here */
    handleCmdDeleteChangeOrderDecisionChangeOrderDecisionIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteChangeOrderDecisionChangeOrderDecisionId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "qryListChangeOrderDecisionState", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "qryListChangeOrderDecisionData", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionState", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionChangeOrder", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionMadeByPlatformUser", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionDecision", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionDecidedAt", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionOutput", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdCreateChangeOrderDecisionError", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionState", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionChangeOrderDecisionId", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionChangeOrder", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionMadeByPlatformUser", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionDecision", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionDecidedAt", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionOutput", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdUpdateChangeOrderDecisionError", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdDeleteChangeOrderDecisionState", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdDeleteChangeOrderDecisionChangeOrderDecisionId", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdDeleteChangeOrderDecisionOutput", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "cmdDeleteChangeOrderDecisionError", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "qryChangeOrderPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmChangeOrderDecisionCatalogueBase.prototype, "qryChangeOrderPickerData", void 0);
