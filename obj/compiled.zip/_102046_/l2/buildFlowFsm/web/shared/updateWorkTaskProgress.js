/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/updateWorkTaskProgress.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryLocateWorkTaskRoute, cmdUpdateWorkTaskRoute, cmdHandoffWorkTaskProgressToFieldCoordinatorRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/updateWorkTaskProgress.js';
/// **collab_i18n_start**
const message_pt = {
    'section.updateWorkTaskProgress.locateWorkTask.title': 'Tarefa selecionada',
    'organism.updateWorkTaskProgress.qryLocateWorkTask.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.empty': 'Nenhum registro encontrado',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.workTaskId.label': 'Work Task Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.projectId.label': 'Project Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.description.label': 'Description',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.status.label': 'Status',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.updateWorkTask.title': 'Registrar andamento',
    'organism.updateWorkTaskProgress.cmdUpdateWorkTask.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.handoffWorkTaskProgressToFieldCoordinator.title': 'Comunicar ao coordenador',
    'organism.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.action.cmdHandoffWorkTaskProgressToFieldCoordinator': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.progressUpdate.label': 'Progress Update',
    'action.cmdUpdateWorkTask.success': 'Registrar o andamento da tarefa: OK',
    'action.cmdUpdateWorkTask.error': 'Registrar o andamento da tarefa: falhou',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.success': 'Informar o andamento ao coordenador: OK',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.error': 'Informar o andamento ao coordenador: falhou',
    'section.updateWorkTaskProgress.taskProgressWorkspace.title': 'Acompanhamento da tarefa',
};
const message_pt_br = {
    'section.updateWorkTaskProgress.locateWorkTask.title': 'Tarefa selecionada',
    'organism.updateWorkTaskProgress.qryLocateWorkTask.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.empty': 'Nenhum registro encontrado',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.workTaskId.label': 'Work Task Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.projectId.label': 'Project Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.description.label': 'Description',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.status.label': 'Status',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.updateWorkTask.title': 'Registrar andamento',
    'organism.updateWorkTaskProgress.cmdUpdateWorkTask.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.handoffWorkTaskProgressToFieldCoordinator.title': 'Comunicar ao coordenador',
    'organism.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.action.cmdHandoffWorkTaskProgressToFieldCoordinator': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.progressUpdate.label': 'Progress Update',
    'action.cmdUpdateWorkTask.success': 'Registrar o andamento da tarefa: OK',
    'action.cmdUpdateWorkTask.error': 'Registrar o andamento da tarefa: falhou',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.success': 'Informar o andamento ao coordenador: OK',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.error': 'Informar o andamento ao coordenador: falhou',
    'section.updateWorkTaskProgress.taskProgressWorkspace.title': 'Acompanhamento da tarefa',
};
const message_en = {
    'section.updateWorkTaskProgress.locateWorkTask.title': 'Tarefa selecionada',
    'organism.updateWorkTaskProgress.qryLocateWorkTask.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.empty': 'Nenhum registro encontrado',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.workTaskId.label': 'Work Task Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.projectId.label': 'Project Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.description.label': 'Description',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.status.label': 'Status',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.updateWorkTask.title': 'Registrar andamento',
    'organism.updateWorkTaskProgress.cmdUpdateWorkTask.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.handoffWorkTaskProgressToFieldCoordinator.title': 'Comunicar ao coordenador',
    'organism.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.action.cmdHandoffWorkTaskProgressToFieldCoordinator': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.progressUpdate.label': 'Progress Update',
    'action.cmdUpdateWorkTask.success': 'Registrar o andamento da tarefa: OK',
    'action.cmdUpdateWorkTask.error': 'Registrar o andamento da tarefa: falhou',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.success': 'Informar o andamento ao coordenador: OK',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.error': 'Informar o andamento ao coordenador: falhou',
    'section.updateWorkTaskProgress.taskProgressWorkspace.title': 'Acompanhamento da tarefa',
};
const message_es = {
    'section.updateWorkTaskProgress.locateWorkTask.title': 'Tarefa selecionada',
    'organism.updateWorkTaskProgress.qryLocateWorkTask.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.title': 'Localizar a tarefa atribuída',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.empty': 'Nenhum registro encontrado',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.workTaskId.label': 'Work Task Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.projectId.label': 'Project Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.description.label': 'Description',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.status.label': 'Status',
    'intent.updateWorkTaskProgress.qryLocateWorkTask.list.column.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.updateWorkTask.title': 'Registrar andamento',
    'organism.updateWorkTaskProgress.cmdUpdateWorkTask.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.title': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Registrar o andamento da tarefa',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdUpdateWorkTask.form.field.progressUpdate.label': 'Progress Update',
    'section.updateWorkTaskProgress.handoffWorkTaskProgressToFieldCoordinator.title': 'Comunicar ao coordenador',
    'organism.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.title': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.action.cmdHandoffWorkTaskProgressToFieldCoordinator': 'Informar o andamento ao coordenador',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.description.label': 'Description',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.dueDate.label': 'Due Date',
    'intent.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator.form.field.progressUpdate.label': 'Progress Update',
    'action.cmdUpdateWorkTask.success': 'Registrar o andamento da tarefa: OK',
    'action.cmdUpdateWorkTask.error': 'Registrar o andamento da tarefa: falhou',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.success': 'Informar o andamento ao coordenador: OK',
    'action.cmdHandoffWorkTaskProgressToFieldCoordinator.error': 'Informar o andamento ao coordenador: falhou',
    'section.updateWorkTaskProgress.taskProgressWorkspace.title': 'Acompanhamento da tarefa',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.updateWorkTaskProgress.status',
    'ui.updateWorkTaskProgress.action.qryLocateWorkTask.status',
    'ui.updateWorkTaskProgress.data.qryLocateWorkTask',
    'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status',
    'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId',
    'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId',
    'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description',
    'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate',
    'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate',
    'ui.updateWorkTaskProgress.output.cmdUpdateWorkTask',
    'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error',
    'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status',
    'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId',
    'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description',
    'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate',
    'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate',
    'ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator',
    'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error',
];
export class BuildFlowFsmUpdateWorkTaskProgressBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryLocateWorkTaskState — actionStatus, values: idle|loading|success|error */
        this.qryLocateWorkTaskState = 'idle';
        /** state qryLocateWorkTaskData — queryResult, outputShape: array */
        this.qryLocateWorkTaskData = [];
        /** state cmdUpdateWorkTaskState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateWorkTaskState = 'idle';
        /** state cmdUpdateWorkTaskProjectProjectId — input */
        this.cmdUpdateWorkTaskProjectProjectId = '';
        /** state cmdUpdateWorkTaskWorkTaskWorkTaskId — input */
        this.cmdUpdateWorkTaskWorkTaskWorkTaskId = '';
        /** state cmdUpdateWorkTaskDescription — input */
        this.cmdUpdateWorkTaskDescription = '';
        /** state cmdUpdateWorkTaskDueDate — input */
        this.cmdUpdateWorkTaskDueDate = '';
        /** state cmdUpdateWorkTaskProgressUpdate — input */
        this.cmdUpdateWorkTaskProgressUpdate = '';
        /** state cmdUpdateWorkTaskOutput — commandOutput */
        this.cmdUpdateWorkTaskOutput = null;
        /** state cmdUpdateWorkTaskError — actionError */
        this.cmdUpdateWorkTaskError = '';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorState — actionStatus, values: idle|loading|success|error */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'idle';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId — input */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId = '';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorDescription — input */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription = '';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate — input */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate = '';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate — input */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate = '';
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorOutput — commandOutput */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorOutput = null;
        /** state cmdHandoffWorkTaskProgressToFieldCoordinatorError — actionError */
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.updateWorkTaskProgress.status', '');
        this.initStateValue('ui.updateWorkTaskProgress.action.qryLocateWorkTask.status', 'idle');
        this.initStateValue('ui.updateWorkTaskProgress.data.qryLocateWorkTask', []);
        this.initStateValue('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'idle');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate', '');
        this.initStateValue('ui.updateWorkTaskProgress.output.cmdUpdateWorkTask', null);
        this.initStateValue('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error', '');
        this.initStateValue('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'idle');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate', '');
        this.initStateValue('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate', '');
        this.initStateValue('ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator', null);
        this.initStateValue('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error', '');
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryLocateWorkTask();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.updateWorkTaskProgress.status':
                this.status = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.action.qryLocateWorkTask.status':
                this.qryLocateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.data.qryLocateWorkTask':
                this.qryLocateWorkTaskData = value ?? [];
                break;
            case 'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId':
                this.cmdUpdateWorkTaskProjectProjectId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId':
                this.cmdUpdateWorkTaskWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description':
                this.cmdUpdateWorkTaskDescription = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate':
                this.cmdUpdateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate':
                this.cmdUpdateWorkTaskProgressUpdate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.output.cmdUpdateWorkTask':
                this.cmdUpdateWorkTaskOutput = value ?? null;
                break;
            case 'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error':
                this.cmdUpdateWorkTaskError = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorOutput = value ?? null;
                break;
            case 'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.updateWorkTaskProgress.status':
                this.status = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.action.qryLocateWorkTask.status':
                this.qryLocateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.data.qryLocateWorkTask':
                this.qryLocateWorkTaskData = value ?? [];
                break;
            case 'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId':
                this.cmdUpdateWorkTaskProjectProjectId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId':
                this.cmdUpdateWorkTaskWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description':
                this.cmdUpdateWorkTaskDescription = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate':
                this.cmdUpdateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate':
                this.cmdUpdateWorkTaskProgressUpdate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.output.cmdUpdateWorkTask':
                this.cmdUpdateWorkTaskOutput = value ?? null;
                break;
            case 'ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error':
                this.cmdUpdateWorkTaskError = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = value ?? 'idle';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate = value ?? '';
                break;
            case 'ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorOutput = value ?? null;
                break;
            case 'ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error':
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/updateWorkTaskProgress(?:\/([^/]+))?\/?$/);
        const rawProjectProjectId = match && match[1] ? match[1] : '';
        let projectProjectId = '';
        if (rawProjectProjectId) {
            try {
                projectProjectId = decodeURIComponent(rawProjectProjectId);
            }
            catch {
                projectProjectId = rawProjectProjectId;
            }
        }
        if (projectProjectId) {
            if (!this.cmdUpdateWorkTaskProjectProjectId) {
                this.cmdUpdateWorkTaskProjectProjectId = projectProjectId;
                setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId', projectProjectId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryLocateWorkTask (query) — route buildFlowFsm.updateWorkTaskProgress.qryLocateWorkTask; inputs: (none); writes ui.updateWorkTaskProgress.data.qryLocateWorkTask; status ui.updateWorkTaskProgress.action.qryLocateWorkTask.status */
    async loadQryLocateWorkTask() {
        this.syncRouteParams();
        this.qryLocateWorkTaskState = 'loading';
        setState('ui.updateWorkTaskProgress.action.qryLocateWorkTask.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateWorkTaskRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateWorkTaskData = data;
            setState('ui.updateWorkTaskProgress.data.qryLocateWorkTask', data);
            this.qryLocateWorkTaskState = 'success';
            setState('ui.updateWorkTaskProgress.action.qryLocateWorkTask.status', 'success');
        }
        else {
            this.qryLocateWorkTaskState = 'error';
            setState('ui.updateWorkTaskProgress.action.qryLocateWorkTask.status', 'error');
            if (response.error) {
                console.error('qryLocateWorkTask failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateWorkTask — bind UI events here */
    handleQryLocateWorkTaskClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateWorkTask();
    }
    /** action cmdUpdateWorkTask (command) — route buildFlowFsm.updateWorkTaskProgress.cmdUpdateWorkTask; inputs: projectProjectId, workTaskWorkTaskId, description, dueDate, progressUpdate; writes ui.updateWorkTaskProgress.output.cmdUpdateWorkTask; status ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status; feedback keys action.cmdUpdateWorkTask.success / action.cmdUpdateWorkTask.error */
    async cmdUpdateWorkTask() {
        this.syncRouteParams();
        if (!this.cmdUpdateWorkTaskProjectProjectId) {
            this.cmdUpdateWorkTaskState = 'idle';
            setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateWorkTaskWorkTaskWorkTaskId) {
            this.cmdUpdateWorkTaskState = 'idle';
            setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateWorkTaskState = 'loading';
        setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'loading');
        this.cmdUpdateWorkTaskError = '';
        setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error', '');
        const params = {
            projectProjectId: this.cmdUpdateWorkTaskProjectProjectId,
            workTaskWorkTaskId: this.cmdUpdateWorkTaskWorkTaskWorkTaskId,
            description: this.cmdUpdateWorkTaskDescription,
            dueDate: this.cmdUpdateWorkTaskDueDate,
        };
        if (this.cmdUpdateWorkTaskProgressUpdate) {
            params.progressUpdate = this.cmdUpdateWorkTaskProgressUpdate;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateWorkTaskRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateWorkTask.error');
            this.cmdUpdateWorkTaskError = errMsg;
            setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.error', errMsg);
            this.cmdUpdateWorkTaskState = 'error';
            setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateWorkTaskOutput = data;
        setState('ui.updateWorkTaskProgress.output.cmdUpdateWorkTask', data);
        try {
            await this.loadQryLocateWorkTask();
            if (this.qryLocateWorkTaskState === 'error') {
                this.cmdUpdateWorkTaskState = 'error';
                setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateWorkTask refresh failed', refreshError);
            this.cmdUpdateWorkTaskState = 'error';
            setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateWorkTaskWorkTaskWorkTaskId = '';
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId', '');
        this.cmdUpdateWorkTaskDescription = '';
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description', '');
        this.cmdUpdateWorkTaskDueDate = '';
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate', '');
        this.cmdUpdateWorkTaskProgressUpdate = '';
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate', '');
        this.cmdUpdateWorkTaskState = 'success';
        setState('ui.updateWorkTaskProgress.action.cmdUpdateWorkTask.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateWorkTask — bind UI events here */
    handleCmdUpdateWorkTaskClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateWorkTask();
        });
    }
    /** action cmdHandoffWorkTaskProgressToFieldCoordinator (command) — route buildFlowFsm.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator; inputs: workTaskWorkTaskId, description, dueDate, progressUpdate; writes ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator; status ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status; feedback keys action.cmdHandoffWorkTaskProgressToFieldCoordinator.success / action.cmdHandoffWorkTaskProgressToFieldCoordinator.error */
    async cmdHandoffWorkTaskProgressToFieldCoordinator() {
        this.syncRouteParams();
        if (!this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId) {
            this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'idle';
            setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'loading';
        setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'loading');
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorError = '';
        setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error', '');
        const params = {
            workTaskWorkTaskId: this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId,
            description: this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription,
            dueDate: this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate,
        };
        if (this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate) {
            params.progressUpdate = this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdHandoffWorkTaskProgressToFieldCoordinatorRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdHandoffWorkTaskProgressToFieldCoordinator.error');
            this.cmdHandoffWorkTaskProgressToFieldCoordinatorError = errMsg;
            setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.error', errMsg);
            this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'error';
            setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorOutput = data;
        setState('ui.updateWorkTaskProgress.output.cmdHandoffWorkTaskProgressToFieldCoordinator', data);
        try {
            await this.loadQryLocateWorkTask();
            if (this.qryLocateWorkTaskState === 'error') {
                this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'error';
                setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdHandoffWorkTaskProgressToFieldCoordinator refresh failed', refreshError);
            this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'error';
            setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId = '';
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId', '');
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription = '';
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description', '');
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate = '';
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate', '');
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate = '';
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate', '');
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorState = 'success';
        setState('ui.updateWorkTaskProgress.action.cmdHandoffWorkTaskProgressToFieldCoordinator.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdHandoffWorkTaskProgressToFieldCoordinator — bind UI events here */
    handleCmdHandoffWorkTaskProgressToFieldCoordinatorClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdHandoffWorkTaskProgressToFieldCoordinator();
        });
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId */
    setCmdUpdateWorkTaskProjectProjectId(value) {
        this.cmdUpdateWorkTaskProjectProjectId = value;
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.projectProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskProjectProjectId — bind UI events here */
    handleCmdUpdateWorkTaskProjectProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskProjectProjectId(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId */
    setCmdUpdateWorkTaskWorkTaskWorkTaskId(value) {
        this.cmdUpdateWorkTaskWorkTaskWorkTaskId = value;
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.workTaskWorkTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskWorkTaskWorkTaskId — bind UI events here */
    handleCmdUpdateWorkTaskWorkTaskWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskWorkTaskWorkTaskId(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description */
    setCmdUpdateWorkTaskDescription(value) {
        this.cmdUpdateWorkTaskDescription = value;
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDescription — bind UI events here */
    handleCmdUpdateWorkTaskDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskDescription(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate */
    setCmdUpdateWorkTaskDueDate(value) {
        this.cmdUpdateWorkTaskDueDate = value;
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDueDate — bind UI events here */
    handleCmdUpdateWorkTaskDueDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskDueDate(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate */
    setCmdUpdateWorkTaskProgressUpdate(value) {
        this.cmdUpdateWorkTaskProgressUpdate = value;
        setState('ui.updateWorkTaskProgress.input.cmdUpdateWorkTask.progressUpdate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskProgressUpdate — bind UI events here */
    handleCmdUpdateWorkTaskProgressUpdateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskProgressUpdate(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId */
    setCmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId(value) {
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId = value;
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.workTaskWorkTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId — bind UI events here */
    handleCmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description */
    setCmdHandoffWorkTaskProgressToFieldCoordinatorDescription(value) {
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription = value;
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffWorkTaskProgressToFieldCoordinatorDescription — bind UI events here */
    handleCmdHandoffWorkTaskProgressToFieldCoordinatorDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffWorkTaskProgressToFieldCoordinatorDescription(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate */
    setCmdHandoffWorkTaskProgressToFieldCoordinatorDueDate(value) {
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate = value;
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate — bind UI events here */
    handleCmdHandoffWorkTaskProgressToFieldCoordinatorDueDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffWorkTaskProgressToFieldCoordinatorDueDate(value);
    }
    /** setter for state ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate */
    setCmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate(value) {
        this.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate = value;
        setState('ui.updateWorkTaskProgress.input.cmdHandoffWorkTaskProgressToFieldCoordinator.progressUpdate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate — bind UI events here */
    handleCmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate(value);
    }
}
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "qryLocateWorkTaskState", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "qryLocateWorkTaskData", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskState", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskProjectProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskWorkTaskWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskDescription", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskDueDate", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskProgressUpdate", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskOutput", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdUpdateWorkTaskError", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorState", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorWorkTaskWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorDescription", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorDueDate", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorProgressUpdate", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorOutput", void 0);
__decorate([
    property()
], BuildFlowFsmUpdateWorkTaskProgressBase.prototype, "cmdHandoffWorkTaskProgressToFieldCoordinatorError", void 0);
