/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/monitorDailyProjectRecords.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryLocateProjectRoute, qryInspectProjectTimeLogsRoute, qryInspectProjectMaterialUsagesRoute, qryInspectProjectExecutionOverviewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/monitorDailyProjectRecords.js';
/// **collab_i18n_start**
const message_pt = {
    'section.monitorDailyProjectRecords.project-selection.title': 'Seleção da obra',
    'organism.monitorDailyProjectRecords.qryLocateProject.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.clientId.label': 'Client Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.name.label': 'Name',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.address.label': 'Address',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedEndDate.label': 'Planned End Date',
    'section.monitorDailyProjectRecords.execution-monitoring.title': 'Acompanhamento da execução',
    'organism.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectName.label': 'Project Name',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectStatus.label': 'Project Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.taskSummary.label': 'Task Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualCost.label': 'Actual Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.budgetAmount.label': 'Budget Amount',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.costVariance.label': 'Cost Variance',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.calculatedAt.label': 'Calculated At',
    'organism.monitorDailyProjectRecords.qryInspectProjectTimeLogs.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.timeLogId.label': 'Time Log Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workTaskId.label': 'Work Task Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workDate.label': 'Work Date',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hoursWorked.label': 'Hours Worked',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.quantity.label': 'Quantity',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.usageDescription.label': 'Usage Description',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.consumedOn.label': 'Consumed On',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'section.monitorDailyProjectRecords.project-monitoring.title': 'Acompanhamento da obra',
    'section.monitorDailyProjectRecords.project-selection-and-overview.title': 'Seleção e visão executiva da obra',
    'section.monitorDailyProjectRecords.daily-records-inspection.title': 'Registros diários para investigação',
};
const message_pt_br = {
    'section.monitorDailyProjectRecords.project-selection.title': 'Seleção da obra',
    'organism.monitorDailyProjectRecords.qryLocateProject.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.clientId.label': 'Client Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.name.label': 'Name',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.address.label': 'Address',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedEndDate.label': 'Planned End Date',
    'section.monitorDailyProjectRecords.execution-monitoring.title': 'Acompanhamento da execução',
    'organism.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectName.label': 'Project Name',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectStatus.label': 'Project Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.taskSummary.label': 'Task Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualCost.label': 'Actual Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.budgetAmount.label': 'Budget Amount',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.costVariance.label': 'Cost Variance',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.calculatedAt.label': 'Calculated At',
    'organism.monitorDailyProjectRecords.qryInspectProjectTimeLogs.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.timeLogId.label': 'Time Log Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workTaskId.label': 'Work Task Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workDate.label': 'Work Date',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hoursWorked.label': 'Hours Worked',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.quantity.label': 'Quantity',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.usageDescription.label': 'Usage Description',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.consumedOn.label': 'Consumed On',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'section.monitorDailyProjectRecords.project-monitoring.title': 'Acompanhamento da obra',
    'section.monitorDailyProjectRecords.project-selection-and-overview.title': 'Seleção e visão executiva da obra',
    'section.monitorDailyProjectRecords.daily-records-inspection.title': 'Registros diários para investigação',
};
const message_en = {
    'section.monitorDailyProjectRecords.project-selection.title': 'Seleção da obra',
    'organism.monitorDailyProjectRecords.qryLocateProject.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.clientId.label': 'Client Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.name.label': 'Name',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.address.label': 'Address',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedEndDate.label': 'Planned End Date',
    'section.monitorDailyProjectRecords.execution-monitoring.title': 'Acompanhamento da execução',
    'organism.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectName.label': 'Project Name',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectStatus.label': 'Project Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.taskSummary.label': 'Task Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualCost.label': 'Actual Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.budgetAmount.label': 'Budget Amount',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.costVariance.label': 'Cost Variance',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.calculatedAt.label': 'Calculated At',
    'organism.monitorDailyProjectRecords.qryInspectProjectTimeLogs.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.timeLogId.label': 'Time Log Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workTaskId.label': 'Work Task Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workDate.label': 'Work Date',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hoursWorked.label': 'Hours Worked',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.quantity.label': 'Quantity',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.usageDescription.label': 'Usage Description',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.consumedOn.label': 'Consumed On',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'section.monitorDailyProjectRecords.project-monitoring.title': 'Acompanhamento da obra',
    'section.monitorDailyProjectRecords.project-selection-and-overview.title': 'Seleção e visão executiva da obra',
    'section.monitorDailyProjectRecords.daily-records-inspection.title': 'Registros diários para investigação',
};
const message_es = {
    'section.monitorDailyProjectRecords.project-selection.title': 'Seleção da obra',
    'organism.monitorDailyProjectRecords.qryLocateProject.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.title': 'Selecionar a obra que exige atenção',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.clientId.label': 'Client Id',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.name.label': 'Name',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.address.label': 'Address',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.monitorDailyProjectRecords.qryLocateProject.list.column.plannedEndDate.label': 'Planned End Date',
    'section.monitorDailyProjectRecords.execution-monitoring.title': 'Acompanhamento da execução',
    'organism.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.title': 'Analisar a execução da obra',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectName.label': 'Project Name',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.projectStatus.label': 'Project Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.taskSummary.label': 'Task Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.actualCost.label': 'Actual Cost',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.budgetAmount.label': 'Budget Amount',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.costVariance.label': 'Cost Variance',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.monitorDailyProjectRecords.qryInspectProjectExecutionOverview.list.column.calculatedAt.label': 'Calculated At',
    'organism.monitorDailyProjectRecords.qryInspectProjectTimeLogs.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.title': 'Consultar os registros diários de horas',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.timeLogId.label': 'Time Log Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workTaskId.label': 'Work Task Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.workDate.label': 'Work Date',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hoursWorked.label': 'Hours Worked',
    'intent.monitorDailyProjectRecords.qryInspectProjectTimeLogs.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.title': 'Consultar os consumos de materiais',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.materialUsageId.label': 'Material Usage Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.status.label': 'Status',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.projectId.label': 'Project Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryItemId.label': 'Inventory Item Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.inventoryBalanceId.label': 'Inventory Balance Id',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.quantity.label': 'Quantity',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.usageDescription.label': 'Usage Description',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.consumedOn.label': 'Consumed On',
    'intent.monitorDailyProjectRecords.qryInspectProjectMaterialUsages.list.column.unitCostBasis.label': 'Unit Cost Basis',
    'section.monitorDailyProjectRecords.project-monitoring.title': 'Acompanhamento da obra',
    'section.monitorDailyProjectRecords.project-selection-and-overview.title': 'Seleção e visão executiva da obra',
    'section.monitorDailyProjectRecords.daily-records-inspection.title': 'Registros diários para investigação',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.monitorDailyProjectRecords.status',
    'ui.monitorDailyProjectRecords.action.qryLocateProject.status',
    'ui.monitorDailyProjectRecords.data.qryLocateProject',
    'ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status',
    'ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId',
    'ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs',
    'ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status',
    'ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId',
    'ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages',
    'ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status',
    'ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId',
    'ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview',
];
export class BuildFlowFsmMonitorDailyProjectRecordsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryLocateProjectState — actionStatus, values: idle|loading|success|error */
        this.qryLocateProjectState = 'idle';
        /** state qryLocateProjectData — queryResult, outputShape: array */
        this.qryLocateProjectData = [];
        /** state qryInspectProjectTimeLogsState — actionStatus, values: idle|loading|success|error */
        this.qryInspectProjectTimeLogsState = 'idle';
        /** state qryInspectProjectTimeLogsTimeLogTimeLogId — input */
        this.qryInspectProjectTimeLogsTimeLogTimeLogId = '';
        /** state qryInspectProjectTimeLogsData — queryResult, outputShape: object */
        this.qryInspectProjectTimeLogsData = null;
        /** state qryInspectProjectMaterialUsagesState — actionStatus, values: idle|loading|success|error */
        this.qryInspectProjectMaterialUsagesState = 'idle';
        /** state qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId — input */
        this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId = '';
        /** state qryInspectProjectMaterialUsagesData — queryResult, outputShape: object */
        this.qryInspectProjectMaterialUsagesData = null;
        /** state qryInspectProjectExecutionOverviewState — actionStatus, values: idle|loading|success|error */
        this.qryInspectProjectExecutionOverviewState = 'idle';
        /** state qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId — input */
        this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId = '';
        /** state qryInspectProjectExecutionOverviewData — queryResult, outputShape: object */
        this.qryInspectProjectExecutionOverviewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.monitorDailyProjectRecords.status', '');
        this.initStateValue('ui.monitorDailyProjectRecords.action.qryLocateProject.status', 'idle');
        this.initStateValue('ui.monitorDailyProjectRecords.data.qryLocateProject', []);
        this.initStateValue('ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status', 'idle');
        this.initStateValue('ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId', '');
        this.initStateValue('ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs', null);
        this.initStateValue('ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status', 'idle');
        this.initStateValue('ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId', '');
        this.initStateValue('ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages', null);
        this.initStateValue('ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status', 'idle');
        this.initStateValue('ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId', '');
        this.initStateValue('ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryLocateProject();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.monitorDailyProjectRecords.status':
                this.status = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.action.qryLocateProject.status':
                this.qryLocateProjectState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryLocateProject':
                this.qryLocateProjectData = value ?? [];
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status':
                this.qryInspectProjectTimeLogsState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId':
                this.qryInspectProjectTimeLogsTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs':
                this.qryInspectProjectTimeLogsData = value ?? null;
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status':
                this.qryInspectProjectMaterialUsagesState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId':
                this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages':
                this.qryInspectProjectMaterialUsagesData = value ?? null;
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status':
                this.qryInspectProjectExecutionOverviewState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId':
                this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview':
                this.qryInspectProjectExecutionOverviewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.monitorDailyProjectRecords.status':
                this.status = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.action.qryLocateProject.status':
                this.qryLocateProjectState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryLocateProject':
                this.qryLocateProjectData = value ?? [];
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status':
                this.qryInspectProjectTimeLogsState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId':
                this.qryInspectProjectTimeLogsTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs':
                this.qryInspectProjectTimeLogsData = value ?? null;
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status':
                this.qryInspectProjectMaterialUsagesState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId':
                this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages':
                this.qryInspectProjectMaterialUsagesData = value ?? null;
                break;
            case 'ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status':
                this.qryInspectProjectExecutionOverviewState = value ?? 'idle';
                break;
            case 'ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId':
                this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId = value ?? '';
                break;
            case 'ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview':
                this.qryInspectProjectExecutionOverviewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryLocateProject (query) — route buildFlowFsm.monitorDailyProjectRecords.qryLocateProject; inputs: (none); writes ui.monitorDailyProjectRecords.data.qryLocateProject; status ui.monitorDailyProjectRecords.action.qryLocateProject.status */
    async loadQryLocateProject() {
        this.qryLocateProjectState = 'loading';
        setState('ui.monitorDailyProjectRecords.action.qryLocateProject.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateProjectRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateProjectData = data;
            setState('ui.monitorDailyProjectRecords.data.qryLocateProject', data);
            this.qryLocateProjectState = 'success';
            setState('ui.monitorDailyProjectRecords.action.qryLocateProject.status', 'success');
        }
        else {
            this.qryLocateProjectState = 'error';
            setState('ui.monitorDailyProjectRecords.action.qryLocateProject.status', 'error');
            if (response.error) {
                console.error('qryLocateProject failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateProject — bind UI events here */
    handleQryLocateProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateProject();
    }
    /** action qryInspectProjectTimeLogs (query) — route buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectTimeLogs; inputs: timeLogTimeLogId; writes ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs; status ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status */
    async loadQryInspectProjectTimeLogs() {
        if (!this.qryInspectProjectTimeLogsTimeLogTimeLogId) {
            this.qryInspectProjectTimeLogsState = 'idle';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryInspectProjectTimeLogsState = 'loading';
        setState('ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status', 'loading');
        const params = {
            timeLogTimeLogId: this.qryInspectProjectTimeLogsTimeLogTimeLogId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryInspectProjectTimeLogsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryInspectProjectTimeLogsData = data;
            setState('ui.monitorDailyProjectRecords.data.qryInspectProjectTimeLogs', data);
            this.qryInspectProjectTimeLogsState = 'success';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status', 'success');
        }
        else {
            this.qryInspectProjectTimeLogsState = 'error';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectTimeLogs.status', 'error');
            if (response.error) {
                console.error('qryInspectProjectTimeLogs failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInspectProjectTimeLogs — bind UI events here */
    handleQryInspectProjectTimeLogsClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInspectProjectTimeLogs();
    }
    /** action qryInspectProjectMaterialUsages (query) — route buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectMaterialUsages; inputs: materialUsageMaterialUsageId; writes ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages; status ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status */
    async loadQryInspectProjectMaterialUsages() {
        if (!this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId) {
            this.qryInspectProjectMaterialUsagesState = 'idle';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryInspectProjectMaterialUsagesState = 'loading';
        setState('ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status', 'loading');
        const params = {
            materialUsageMaterialUsageId: this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryInspectProjectMaterialUsagesRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryInspectProjectMaterialUsagesData = data;
            setState('ui.monitorDailyProjectRecords.data.qryInspectProjectMaterialUsages', data);
            this.qryInspectProjectMaterialUsagesState = 'success';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status', 'success');
        }
        else {
            this.qryInspectProjectMaterialUsagesState = 'error';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectMaterialUsages.status', 'error');
            if (response.error) {
                console.error('qryInspectProjectMaterialUsages failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInspectProjectMaterialUsages — bind UI events here */
    handleQryInspectProjectMaterialUsagesClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInspectProjectMaterialUsages();
    }
    /** action qryInspectProjectExecutionOverview (query) — route buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectExecutionOverview; inputs: projectExecutionOverviewProjectId; writes ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview; status ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status */
    async loadQryInspectProjectExecutionOverview() {
        if (!this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId) {
            this.qryInspectProjectExecutionOverviewState = 'idle';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryInspectProjectExecutionOverviewState = 'loading';
        setState('ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status', 'loading');
        const params = {
            projectExecutionOverviewProjectId: this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryInspectProjectExecutionOverviewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryInspectProjectExecutionOverviewData = data;
            setState('ui.monitorDailyProjectRecords.data.qryInspectProjectExecutionOverview', data);
            this.qryInspectProjectExecutionOverviewState = 'success';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status', 'success');
        }
        else {
            this.qryInspectProjectExecutionOverviewState = 'error';
            setState('ui.monitorDailyProjectRecords.action.qryInspectProjectExecutionOverview.status', 'error');
            if (response.error) {
                console.error('qryInspectProjectExecutionOverview failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryInspectProjectExecutionOverview — bind UI events here */
    handleQryInspectProjectExecutionOverviewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryInspectProjectExecutionOverview();
    }
    /** setter for state ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId */
    setQryInspectProjectTimeLogsTimeLogTimeLogId(value) {
        this.qryInspectProjectTimeLogsTimeLogTimeLogId = value;
        setState('ui.monitorDailyProjectRecords.input.qryInspectProjectTimeLogs.timeLogTimeLogId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryInspectProjectTimeLogsTimeLogTimeLogId — bind UI events here */
    handleQryInspectProjectTimeLogsTimeLogTimeLogIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryInspectProjectTimeLogsTimeLogTimeLogId(value);
    }
    /** setter for state ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId */
    setQryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId(value) {
        this.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId = value;
        setState('ui.monitorDailyProjectRecords.input.qryInspectProjectMaterialUsages.materialUsageMaterialUsageId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId — bind UI events here */
    handleQryInspectProjectMaterialUsagesMaterialUsageMaterialUsageIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId(value);
    }
    /** setter for state ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId */
    setQryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId(value) {
        this.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId = value;
        setState('ui.monitorDailyProjectRecords.input.qryInspectProjectExecutionOverview.projectExecutionOverviewProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId — bind UI events here */
    handleQryInspectProjectExecutionOverviewProjectExecutionOverviewProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryLocateProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryLocateProjectData", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectTimeLogsState", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectTimeLogsTimeLogTimeLogId", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectTimeLogsData", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectMaterialUsagesState", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectMaterialUsagesMaterialUsageMaterialUsageId", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectMaterialUsagesData", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectExecutionOverviewState", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectExecutionOverviewProjectExecutionOverviewProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmMonitorDailyProjectRecordsBase.prototype, "qryInspectProjectExecutionOverviewData", void 0);
