/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/clientBillingSummaryView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryClientBillingSummaryViewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/clientBillingSummaryView.js';
/// **collab_i18n_start**
const message_pt = {
    'section.clientBillingSummaryView.overview.title': 'Resumo de faturamento',
    'organism.clientBillingSummaryView.qryClientBillingSummaryView.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.empty': 'Nenhum registro encontrado',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientId.label': 'Client Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.projectId.label': 'Project Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderReferences.label': 'Approved Change Order References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoiceReferences.label': 'Invoice References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderAmount.label': 'Approved Change Order Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.billableAmount.label': 'Billable Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoicedAmount.label': 'Invoiced Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientAvailableAmount.label': 'Client Available Amount',
};
const message_pt_br = {
    'section.clientBillingSummaryView.overview.title': 'Resumo de faturamento',
    'organism.clientBillingSummaryView.qryClientBillingSummaryView.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.empty': 'Nenhum registro encontrado',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientId.label': 'Client Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.projectId.label': 'Project Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderReferences.label': 'Approved Change Order References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoiceReferences.label': 'Invoice References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderAmount.label': 'Approved Change Order Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.billableAmount.label': 'Billable Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoicedAmount.label': 'Invoiced Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientAvailableAmount.label': 'Client Available Amount',
};
const message_en = {
    'section.clientBillingSummaryView.overview.title': 'Resumo de faturamento',
    'organism.clientBillingSummaryView.qryClientBillingSummaryView.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.empty': 'Nenhum registro encontrado',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientId.label': 'Client Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.projectId.label': 'Project Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderReferences.label': 'Approved Change Order References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoiceReferences.label': 'Invoice References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderAmount.label': 'Approved Change Order Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.billableAmount.label': 'Billable Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoicedAmount.label': 'Invoiced Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientAvailableAmount.label': 'Client Available Amount',
};
const message_es = {
    'section.clientBillingSummaryView.overview.title': 'Resumo de faturamento',
    'organism.clientBillingSummaryView.qryClientBillingSummaryView.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.title': 'Consultar o resumo de faturamento',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.empty': 'Nenhum registro encontrado',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientId.label': 'Client Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.projectId.label': 'Project Id',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderReferences.label': 'Approved Change Order References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoiceReferences.label': 'Invoice References',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.approvedChangeOrderAmount.label': 'Approved Change Order Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.billableAmount.label': 'Billable Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.invoicedAmount.label': 'Invoiced Amount',
    'intent.clientBillingSummaryView.qryClientBillingSummaryView.list.column.clientAvailableAmount.label': 'Client Available Amount',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.clientBillingSummaryView.status',
    'ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status',
    'ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId',
    'ui.clientBillingSummaryView.data.qryClientBillingSummaryView',
];
export class BuildFlowFsmClientBillingSummaryViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryClientBillingSummaryViewState — actionStatus, values: idle|loading|success|error */
        this.qryClientBillingSummaryViewState = 'idle';
        /** state qryClientBillingSummaryViewClientBillingSummaryClientId — input */
        this.qryClientBillingSummaryViewClientBillingSummaryClientId = '';
        /** state qryClientBillingSummaryViewData — queryResult, outputShape: object */
        this.qryClientBillingSummaryViewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.clientBillingSummaryView.status', '');
        this.initStateValue('ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status', 'idle');
        this.initStateValue('ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId', '');
        this.initStateValue('ui.clientBillingSummaryView.data.qryClientBillingSummaryView', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.clientBillingSummaryView.status':
                this.status = value ?? '';
                break;
            case 'ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status':
                this.qryClientBillingSummaryViewState = value ?? 'idle';
                break;
            case 'ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId':
                this.qryClientBillingSummaryViewClientBillingSummaryClientId = value ?? '';
                break;
            case 'ui.clientBillingSummaryView.data.qryClientBillingSummaryView':
                this.qryClientBillingSummaryViewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.clientBillingSummaryView.status':
                this.status = value ?? '';
                break;
            case 'ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status':
                this.qryClientBillingSummaryViewState = value ?? 'idle';
                break;
            case 'ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId':
                this.qryClientBillingSummaryViewClientBillingSummaryClientId = value ?? '';
                break;
            case 'ui.clientBillingSummaryView.data.qryClientBillingSummaryView':
                this.qryClientBillingSummaryViewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryClientBillingSummaryView (query) — route buildFlowFsm.clientBillingSummaryView.qryClientBillingSummaryView; inputs: clientBillingSummaryClientId; writes ui.clientBillingSummaryView.data.qryClientBillingSummaryView; status ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status */
    async loadQryClientBillingSummaryView() {
        if (!this.qryClientBillingSummaryViewClientBillingSummaryClientId) {
            this.qryClientBillingSummaryViewState = 'idle';
            setState('ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryClientBillingSummaryViewState = 'loading';
        setState('ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status', 'loading');
        const params = {
            clientBillingSummaryClientId: this.qryClientBillingSummaryViewClientBillingSummaryClientId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryClientBillingSummaryViewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryClientBillingSummaryViewData = data;
            setState('ui.clientBillingSummaryView.data.qryClientBillingSummaryView', data);
            this.qryClientBillingSummaryViewState = 'success';
            setState('ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status', 'success');
        }
        else {
            this.qryClientBillingSummaryViewState = 'error';
            setState('ui.clientBillingSummaryView.action.qryClientBillingSummaryView.status', 'error');
            if (response.error) {
                console.error('qryClientBillingSummaryView failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryClientBillingSummaryView — bind UI events here */
    handleQryClientBillingSummaryViewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryClientBillingSummaryView();
    }
    /** setter for state ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId */
    setQryClientBillingSummaryViewClientBillingSummaryClientId(value) {
        this.qryClientBillingSummaryViewClientBillingSummaryClientId = value;
        setState('ui.clientBillingSummaryView.input.qryClientBillingSummaryView.clientBillingSummaryClientId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryClientBillingSummaryViewClientBillingSummaryClientId — bind UI events here */
    handleQryClientBillingSummaryViewClientBillingSummaryClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryClientBillingSummaryViewClientBillingSummaryClientId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmClientBillingSummaryViewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmClientBillingSummaryViewBase.prototype, "qryClientBillingSummaryViewState", void 0);
__decorate([
    property()
], BuildFlowFsmClientBillingSummaryViewBase.prototype, "qryClientBillingSummaryViewClientBillingSummaryClientId", void 0);
__decorate([
    property()
], BuildFlowFsmClientBillingSummaryViewBase.prototype, "qryClientBillingSummaryViewData", void 0);
