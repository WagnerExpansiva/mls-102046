/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/forwardChangeOrderForClientApproval.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryLocateChangeOrderRoute, cmdHandoffChangeOrderToClientRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/forwardChangeOrderForClientApproval.js';
/// **collab_i18n_start**
const message_pt = {
    'section.forwardChangeOrderForClientApproval.locateChangeOrder.title': 'Localizar ordem de mudança',
    'organism.forwardChangeOrderForClientApproval.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.forwardChangeOrderForClientApproval.handoffChangeOrderToClient.title': 'Encaminhar para aprovação do cliente',
    'organism.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.action.cmdHandoffChangeOrderToClient': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.changeAmount.label': 'Change Amount',
    'action.cmdHandoffChangeOrderToClient.success': 'Solicitar aprovação do cliente: OK',
    'action.cmdHandoffChangeOrderToClient.error': 'Solicitar aprovação do cliente: falhou',
    'section.forwardChangeOrderForClientApproval.change-order-workspace.title': 'Ordem de mudança para encaminhamento',
    'section.forwardChangeOrderForClientApproval.changeOrderApprovalWorkspace.title': 'Ordem de mudança para aprovação',
};
const message_pt_br = {
    'section.forwardChangeOrderForClientApproval.locateChangeOrder.title': 'Localizar ordem de mudança',
    'organism.forwardChangeOrderForClientApproval.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.forwardChangeOrderForClientApproval.handoffChangeOrderToClient.title': 'Encaminhar para aprovação do cliente',
    'organism.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.action.cmdHandoffChangeOrderToClient': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.changeAmount.label': 'Change Amount',
    'action.cmdHandoffChangeOrderToClient.success': 'Solicitar aprovação do cliente: OK',
    'action.cmdHandoffChangeOrderToClient.error': 'Solicitar aprovação do cliente: falhou',
    'section.forwardChangeOrderForClientApproval.change-order-workspace.title': 'Ordem de mudança para encaminhamento',
    'section.forwardChangeOrderForClientApproval.changeOrderApprovalWorkspace.title': 'Ordem de mudança para aprovação',
};
const message_en = {
    'section.forwardChangeOrderForClientApproval.locateChangeOrder.title': 'Localizar ordem de mudança',
    'organism.forwardChangeOrderForClientApproval.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.forwardChangeOrderForClientApproval.handoffChangeOrderToClient.title': 'Encaminhar para aprovação do cliente',
    'organism.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.action.cmdHandoffChangeOrderToClient': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.changeAmount.label': 'Change Amount',
    'action.cmdHandoffChangeOrderToClient.success': 'Solicitar aprovação do cliente: OK',
    'action.cmdHandoffChangeOrderToClient.error': 'Solicitar aprovação do cliente: falhou',
    'section.forwardChangeOrderForClientApproval.change-order-workspace.title': 'Ordem de mudança para encaminhamento',
    'section.forwardChangeOrderForClientApproval.changeOrderApprovalWorkspace.title': 'Ordem de mudança para aprovação',
};
const message_es = {
    'section.forwardChangeOrderForClientApproval.locateChangeOrder.title': 'Localizar ordem de mudança',
    'organism.forwardChangeOrderForClientApproval.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.forwardChangeOrderForClientApproval.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.forwardChangeOrderForClientApproval.handoffChangeOrderToClient.title': 'Encaminhar para aprovação do cliente',
    'organism.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.title': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.action.cmdHandoffChangeOrderToClient': 'Solicitar aprovação do cliente',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.description.label': 'Description',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scopeImpact.label': 'Scope Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient.form.field.changeAmount.label': 'Change Amount',
    'action.cmdHandoffChangeOrderToClient.success': 'Solicitar aprovação do cliente: OK',
    'action.cmdHandoffChangeOrderToClient.error': 'Solicitar aprovação do cliente: falhou',
    'section.forwardChangeOrderForClientApproval.change-order-workspace.title': 'Ordem de mudança para encaminhamento',
    'section.forwardChangeOrderForClientApproval.changeOrderApprovalWorkspace.title': 'Ordem de mudança para aprovação',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.forwardChangeOrderForClientApproval.status',
    'ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status',
    'ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder',
    'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status',
    'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId',
    'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description',
    'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact',
    'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact',
    'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount',
    'ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient',
    'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error',
];
export class BuildFlowFsmForwardChangeOrderForClientApprovalBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryLocateChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.qryLocateChangeOrderState = 'idle';
        /** state qryLocateChangeOrderData — queryResult, outputShape: array */
        this.qryLocateChangeOrderData = [];
        /** state cmdHandoffChangeOrderToClientState — actionStatus, values: idle|loading|success|error */
        this.cmdHandoffChangeOrderToClientState = 'idle';
        /** state cmdHandoffChangeOrderToClientChangeOrderChangeOrderId — input */
        this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId = '';
        /** state cmdHandoffChangeOrderToClientDescription — input */
        this.cmdHandoffChangeOrderToClientDescription = '';
        /** state cmdHandoffChangeOrderToClientScopeImpact — input */
        this.cmdHandoffChangeOrderToClientScopeImpact = '';
        /** state cmdHandoffChangeOrderToClientScheduleImpact — input */
        this.cmdHandoffChangeOrderToClientScheduleImpact = '';
        /** state cmdHandoffChangeOrderToClientChangeAmount — input */
        this.cmdHandoffChangeOrderToClientChangeAmount = '';
        /** state cmdHandoffChangeOrderToClientOutput — commandOutput */
        this.cmdHandoffChangeOrderToClientOutput = null;
        /** state cmdHandoffChangeOrderToClientError — actionError */
        this.cmdHandoffChangeOrderToClientError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.forwardChangeOrderForClientApproval.status', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status', 'idle');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder', []);
        this.initStateValue('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'idle');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount', '');
        this.initStateValue('ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient', null);
        this.initStateValue('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error', '');
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryLocateChangeOrder();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.forwardChangeOrderForClientApproval.status':
                this.status = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status':
                this.qryLocateChangeOrderState = value ?? 'idle';
                break;
            case 'ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder':
                this.qryLocateChangeOrderData = value ?? [];
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status':
                this.cmdHandoffChangeOrderToClientState = value ?? 'idle';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId':
                this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description':
                this.cmdHandoffChangeOrderToClientDescription = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact':
                this.cmdHandoffChangeOrderToClientScopeImpact = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact':
                this.cmdHandoffChangeOrderToClientScheduleImpact = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount':
                this.cmdHandoffChangeOrderToClientChangeAmount = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient':
                this.cmdHandoffChangeOrderToClientOutput = value ?? null;
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error':
                this.cmdHandoffChangeOrderToClientError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.forwardChangeOrderForClientApproval.status':
                this.status = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status':
                this.qryLocateChangeOrderState = value ?? 'idle';
                break;
            case 'ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder':
                this.qryLocateChangeOrderData = value ?? [];
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status':
                this.cmdHandoffChangeOrderToClientState = value ?? 'idle';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId':
                this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description':
                this.cmdHandoffChangeOrderToClientDescription = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact':
                this.cmdHandoffChangeOrderToClientScopeImpact = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact':
                this.cmdHandoffChangeOrderToClientScheduleImpact = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount':
                this.cmdHandoffChangeOrderToClientChangeAmount = value ?? '';
                break;
            case 'ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient':
                this.cmdHandoffChangeOrderToClientOutput = value ?? null;
                break;
            case 'ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error':
                this.cmdHandoffChangeOrderToClientError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryLocateChangeOrder (query) — route buildFlowFsm.forwardChangeOrderForClientApproval.qryLocateChangeOrder; inputs: (none); writes ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder; status ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status */
    async loadQryLocateChangeOrder() {
        this.qryLocateChangeOrderState = 'loading';
        setState('ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateChangeOrderRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateChangeOrderData = data;
            setState('ui.forwardChangeOrderForClientApproval.data.qryLocateChangeOrder', data);
            this.qryLocateChangeOrderState = 'success';
            setState('ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status', 'success');
        }
        else {
            this.qryLocateChangeOrderState = 'error';
            setState('ui.forwardChangeOrderForClientApproval.action.qryLocateChangeOrder.status', 'error');
            if (response.error) {
                console.error('qryLocateChangeOrder failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateChangeOrder — bind UI events here */
    handleQryLocateChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateChangeOrder();
    }
    /** action cmdHandoffChangeOrderToClient (command) — route buildFlowFsm.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient; inputs: changeOrderChangeOrderId, description, scopeImpact, scheduleImpact, changeAmount; writes ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient; status ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status; feedback keys action.cmdHandoffChangeOrderToClient.success / action.cmdHandoffChangeOrderToClient.error */
    async cmdHandoffChangeOrderToClient() {
        if (!this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId) {
            this.cmdHandoffChangeOrderToClientState = 'idle';
            setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffChangeOrderToClientState = 'loading';
        setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'loading');
        this.cmdHandoffChangeOrderToClientError = '';
        setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error', '');
        const changeAmountNum = Number(this.cmdHandoffChangeOrderToClientChangeAmount);
        const params = {
            changeOrderChangeOrderId: this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId,
            description: this.cmdHandoffChangeOrderToClientDescription,
            scopeImpact: this.cmdHandoffChangeOrderToClientScopeImpact,
            scheduleImpact: this.cmdHandoffChangeOrderToClientScheduleImpact,
            changeAmount: Number.isNaN(changeAmountNum) ? 0 : changeAmountNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdHandoffChangeOrderToClientRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdHandoffChangeOrderToClient.error');
            this.cmdHandoffChangeOrderToClientError = errMsg;
            setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.error', errMsg);
            this.cmdHandoffChangeOrderToClientState = 'error';
            setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdHandoffChangeOrderToClientOutput = data;
        setState('ui.forwardChangeOrderForClientApproval.output.cmdHandoffChangeOrderToClient', data);
        try {
            await this.loadQryLocateChangeOrder();
            if (this.qryLocateChangeOrderState === 'error') {
                this.cmdHandoffChangeOrderToClientState = 'error';
                setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdHandoffChangeOrderToClient refresh failed', refreshError);
            this.cmdHandoffChangeOrderToClientState = 'error';
            setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId = '';
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId', '');
        this.cmdHandoffChangeOrderToClientDescription = '';
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description', '');
        this.cmdHandoffChangeOrderToClientScopeImpact = '';
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact', '');
        this.cmdHandoffChangeOrderToClientScheduleImpact = '';
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact', '');
        this.cmdHandoffChangeOrderToClientChangeAmount = '';
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount', '');
        this.cmdHandoffChangeOrderToClientState = 'success';
        setState('ui.forwardChangeOrderForClientApproval.action.cmdHandoffChangeOrderToClient.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdHandoffChangeOrderToClient — bind UI events here */
    handleCmdHandoffChangeOrderToClientClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdHandoffChangeOrderToClient();
        });
    }
    /** setter for state ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId */
    setCmdHandoffChangeOrderToClientChangeOrderChangeOrderId(value) {
        this.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId = value;
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeOrderChangeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffChangeOrderToClientChangeOrderChangeOrderId — bind UI events here */
    handleCmdHandoffChangeOrderToClientChangeOrderChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffChangeOrderToClientChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description */
    setCmdHandoffChangeOrderToClientDescription(value) {
        this.cmdHandoffChangeOrderToClientDescription = value;
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffChangeOrderToClientDescription — bind UI events here */
    handleCmdHandoffChangeOrderToClientDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffChangeOrderToClientDescription(value);
    }
    /** setter for state ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact */
    setCmdHandoffChangeOrderToClientScopeImpact(value) {
        this.cmdHandoffChangeOrderToClientScopeImpact = value;
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scopeImpact', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffChangeOrderToClientScopeImpact — bind UI events here */
    handleCmdHandoffChangeOrderToClientScopeImpactChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffChangeOrderToClientScopeImpact(value);
    }
    /** setter for state ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact */
    setCmdHandoffChangeOrderToClientScheduleImpact(value) {
        this.cmdHandoffChangeOrderToClientScheduleImpact = value;
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.scheduleImpact', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffChangeOrderToClientScheduleImpact — bind UI events here */
    handleCmdHandoffChangeOrderToClientScheduleImpactChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffChangeOrderToClientScheduleImpact(value);
    }
    /** setter for state ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount */
    setCmdHandoffChangeOrderToClientChangeAmount(value) {
        this.cmdHandoffChangeOrderToClientChangeAmount = value;
        setState('ui.forwardChangeOrderForClientApproval.input.cmdHandoffChangeOrderToClient.changeAmount', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffChangeOrderToClientChangeAmount — bind UI events here */
    handleCmdHandoffChangeOrderToClientChangeAmountChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffChangeOrderToClientChangeAmount(value);
    }
}
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "qryLocateChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "qryLocateChangeOrderData", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientState", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientChangeOrderChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientDescription", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientScopeImpact", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientScheduleImpact", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientChangeAmount", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientOutput", void 0);
__decorate([
    property()
], BuildFlowFsmForwardChangeOrderForClientApprovalBase.prototype, "cmdHandoffChangeOrderToClientError", void 0);
