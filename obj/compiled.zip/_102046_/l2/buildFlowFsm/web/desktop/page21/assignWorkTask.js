/// <mls fileReference="_102046_/l2/buildFlowFsm/web/desktop/page21/assignWorkTask.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgLang, _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgCache;
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmAssignWorkTaskBase, messages as sharedMessages } from '/_102046_/l2/buildFlowFsm/web/shared/assignWorkTask.js';
const sharedFallback = sharedMessages[Object.keys(sharedMessages)[0]];
/// **collab_i18n_start**
const fromShared = (m) => ({
    'planning.title': m['section.assignWorkTask.planningContext.title'],
    'projects.title': m['organism.assignWorkTask.qryLocateProject.title'],
    'projects.list': m['intent.assignWorkTask.qryLocateProject.list.title'],
    'projects.empty': m['intent.assignWorkTask.qryLocateProject.list.empty'],
    'project.id': m['intent.assignWorkTask.qryLocateProject.list.column.projectId.label'],
    'project.name': m['intent.assignWorkTask.qryLocateProject.list.column.name.label'],
    'project.address': m['intent.assignWorkTask.qryLocateProject.list.column.address.label'],
    'project.status': m['intent.assignWorkTask.qryLocateProject.list.column.status.label'],
    'project.start': m['intent.assignWorkTask.qryLocateProject.list.column.plannedStartDate.label'],
    'project.end': m['intent.assignWorkTask.qryLocateProject.list.column.plannedEndDate.label'],
    'timeline.title': m['organism.assignWorkTask.qryInspectProjectTimeline.title'],
    'timeline.list': m['intent.assignWorkTask.qryInspectProjectTimeline.list.title'],
    'timeline.empty': m['intent.assignWorkTask.qryInspectProjectTimeline.list.empty'],
    'timeline.tasks': m['intent.assignWorkTask.qryInspectProjectTimeline.list.column.workTasks.label'],
    'timeline.entries': m['intent.assignWorkTask.qryInspectProjectTimeline.list.column.scheduleEntries.label'],
    'workers.title': m['organism.assignWorkTask.qryLocateFieldWorker.title'],
    'workers.list': m['intent.assignWorkTask.qryLocateFieldWorker.list.title'],
    'workers.empty': m['intent.assignWorkTask.qryLocateFieldWorker.list.empty'],
    'worker.id': m['intent.assignWorkTask.qryLocateFieldWorker.list.column.platformUserId.label'],
    'task.title': m['organism.assignWorkTask.cmdCreateWorkTask.title'],
    'task.form': m['intent.assignWorkTask.cmdCreateWorkTask.form.title'],
    'task.create': m['intent.assignWorkTask.cmdCreateWorkTask.form.action.cmdCreateWorkTask'],
    'task.description': m['intent.assignWorkTask.cmdCreateWorkTask.form.field.description.label'],
    'task.due': m['intent.assignWorkTask.cmdCreateWorkTask.form.field.dueDate.label'],
    'task.progress': m['intent.assignWorkTask.cmdCreateWorkTask.form.field.progressUpdate.label'],
    'handoff.title': m['organism.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.title'],
    'handoff.form': m['intent.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.form.title'],
    'handoff.action': m['intent.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.form.action.cmdHandoffWorkTaskToFieldWorker'],
    'handoff.description': m['intent.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.form.field.description.label'],
    'handoff.due': m['intent.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.form.field.dueDate.label'],
    'handoff.progress': m['intent.assignWorkTask.cmdHandoffWorkTaskToFieldWorker.form.field.progressUpdate.label'],
    'create.success': m['action.cmdCreateWorkTask.success'],
    'create.error': m['action.cmdCreateWorkTask.error'],
    'handoff.success': m['action.cmdHandoffWorkTaskToFieldWorker.success'],
    'handoff.error': m['action.cmdHandoffWorkTaskToFieldWorker.error'],
});
const pageMessage_pt = {
    ...fromShared(sharedMessages['pt'] ?? sharedFallback),
    'rail.project': 'Obra', 'rail.context': 'Cronograma', 'rail.worker': 'Trabalhador', 'rail.task': 'Tarefa', 'rail.review': 'Confirmação',
    'choose.project': 'Selecione uma obra', 'choose.worker': 'Trabalhador disponível', 'loading': 'Carregando…', 'required': 'Obrigatório', 'route.context': 'Obra definida pelo contexto da página', 'created': 'Tarefa criada; confirme o encaminhamento', 'not.created': 'Crie a tarefa para liberar o encaminhamento', 'summary': 'Resumo do encaminhamento', 'next': 'Continuar', 'step.done': 'Concluído', 'status.loading': 'Em andamento',
};
const pageMessage_pt_br = {
    ...fromShared(sharedMessages['pt-br'] ?? sharedFallback),
    'rail.project': 'Obra', 'rail.context': 'Cronograma', 'rail.worker': 'Trabalhador', 'rail.task': 'Tarefa', 'rail.review': 'Confirmação', 'choose.project': 'Selecione uma obra', 'choose.worker': 'Trabalhador disponível', 'loading': 'Carregando…', 'required': 'Obrigatório', 'route.context': 'Obra definida pelo contexto da página', 'created': 'Tarefa criada; confirme o encaminhamento', 'not.created': 'Crie a tarefa para liberar o encaminhamento', 'summary': 'Resumo do encaminhamento', 'next': 'Continuar', 'step.done': 'Concluído', 'status.loading': 'Em andamento',
};
const pageMessage_en = {
    ...fromShared(sharedMessages['en'] ?? sharedFallback),
    'rail.project': 'Project', 'rail.context': 'Schedule', 'rail.worker': 'Worker', 'rail.task': 'Task', 'rail.review': 'Confirmation', 'choose.project': 'Select a project', 'choose.worker': 'Available worker', 'loading': 'Loading…', 'required': 'Required', 'route.context': 'Project provided by page context', 'created': 'Task created; confirm dispatch', 'not.created': 'Create the task to enable dispatch', 'summary': 'Dispatch summary', 'next': 'Continue', 'step.done': 'Complete', 'status.loading': 'In progress',
};
const pageMessage_es = {
    ...fromShared(sharedMessages['es'] ?? sharedFallback),
    'rail.project': 'Obra', 'rail.context': 'Cronograma', 'rail.worker': 'Trabajador', 'rail.task': 'Tarea', 'rail.review': 'Confirmación', 'choose.project': 'Seleccione una obra', 'choose.worker': 'Trabajador disponible', 'loading': 'Cargando…', 'required': 'Obligatorio', 'route.context': 'Obra proporcionada por el contexto', 'created': 'Tarea creada; confirme el envío', 'not.created': 'Cree la tarea para habilitar el envío', 'summary': 'Resumen del envío', 'next': 'Continuar', 'step.done': 'Completado', 'status.loading': 'En curso',
};
const pageMessages = { 'pt': pageMessage_pt, 'pt-br': pageMessage_pt_br, 'en': pageMessage_en, 'es': pageMessage_es };
/// **collab_i18n_end**
const pageFallback = pageMessages[Object.keys(pageMessages)[0]];
let BuildFlowFsmDesktopPage21AssignWorkTaskPage = class BuildFlowFsmDesktopPage21AssignWorkTaskPage extends BuildFlowFsmAssignWorkTaskBase {
    constructor() {
        super(...arguments);
        _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgLang.set(this, null);
        _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgCache.set(this, pageFallback);
    }
    get msg() {
        const lang = (document.documentElement.lang || '').toLowerCase();
        if (lang !== __classPrivateFieldGet(this, _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgLang, "f")) {
            __classPrivateFieldSet(this, _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgLang, lang, "f");
            __classPrivateFieldSet(this, _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgCache, pageMessages[this.getMessageKey(pageMessages)] || pageFallback, "f");
        }
        return __classPrivateFieldGet(this, _BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgCache, "f");
    }
    render() {
        const msg = this.msg;
        return html `<main class="min-h-full bg-[var(--page-bg,#ffffff)] text-[var(--text-default,#0f172a)] p-6 space-y-6">
  <nav aria-label=${msg['summary']} class="grid grid-cols-5 gap-2 text-sm">
    ${[msg['rail.project'], msg['rail.context'], msg['rail.worker'], msg['rail.task'], msg['rail.review']].map((label, index) => html `<div class="rounded-lg border border-[var(--border-subtle,#e2e8f0)] p-3 ${index === 0 ? 'bg-[var(--selected-bg,#eef2ff)] text-[var(--selected-text,#1e293b)]' : 'text-[var(--text-muted,#64748b)]'}"><span class="font-bold">${index + 1}</span> ${label}</div>`)}</nav>
  ${this.renderPlanning()}<div class="grid gap-6 lg:grid-cols-2">${this.renderTaskForm()}${this.renderHandoff()}</div>
</main>`;
    }
    renderPlanning() {
        const msg = this.msg;
        const projects = this.qryLocateProjectData;
        const selectedId = this.qryInspectProjectTimelineProjectTimelineProjectId;
        const timeline = this.qryInspectProjectTimelineData;
        return html `<section class="space-y-4"><h2 class="text-xl font-bold">${msg['planning.title']}</h2><div class="grid gap-6 lg:grid-cols-2">
<section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] p-4"><h3 class="font-bold">${msg['projects.list']}</h3>${this.qryLocateProjectState === 'loading' ? html `<p class="text-[var(--text-muted,#64748b)]">${msg['loading']}</p>` : projects.length === 0 ? html `<p>${msg['projects.empty']}</p>` : html `<div class="mt-3 space-y-2">${projects.map((project) => html `<button type="button" class="block w-full rounded-lg border p-3 text-left ${String(project['projectId'] ?? '') === selectedId ? 'border-[var(--selected-border,#4f46e5)] bg-[var(--selected-bg,#eef2ff)]' : 'border-[var(--border-subtle,#e2e8f0)]'}" @click=${(event) => { this.setQryInspectProjectTimelineProjectTimelineProjectId(String(project['projectId'] ?? '')); this.handleQryInspectProjectTimelineClick(event); }}><strong>${String(project['name'] ?? '')}</strong><span class="ml-2 text-sm text-[var(--text-muted,#64748b)]">${String(project['status'] ?? '')}</span><div class="text-sm">${String(project['address'] ?? '')}</div><div class="text-xs text-[var(--text-muted,#64748b)]">${msg['project.start']}: ${String(project['plannedStartDate'] ?? '')} · ${msg['project.end']}: ${String(project['plannedEndDate'] ?? '')}</div></button>`)}</div>`}</section>
<section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-alt-bg,#f8fafc)] p-4"><h3 class="font-bold">${msg['timeline.list']}</h3>${this.qryInspectProjectTimelineState === 'loading' ? html `<p>${msg['loading']}</p>` : timeline === null ? html `<p>${msg['timeline.empty']}</p>` : html `<dl class="mt-3 space-y-3"><div><dt class="font-semibold">${msg['timeline.tasks']}</dt><dd>${String(timeline['workTasks'] ?? '')}</dd></div><div><dt class="font-semibold">${msg['timeline.entries']}</dt><dd>${String(timeline['scheduleEntries'] ?? '')}</dd></div></dl>`}</section></div></section>`;
    }
    renderTaskForm() {
        const msg = this.msg;
        const busy = this.cmdCreateWorkTaskState === 'loading';
        return html `<section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] p-5 space-y-4"><h2 class="text-xl font-bold">${msg['task.form']}</h2><p class="text-sm text-[var(--text-muted,#64748b)]">${msg['route.context']}: ${this.cmdCreateWorkTaskProjectProjectId}</p><label class="block">${msg['task.description']} <span aria-label=${msg['required']}>*</span><textarea required class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdCreateWorkTaskDescription} @change=${(event) => this.handleCmdCreateWorkTaskDescriptionChange(event)}></textarea></label><label class="block">${msg['task.due']} <span aria-label=${msg['required']}>*</span><input required type="date" class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdCreateWorkTaskDueDate} @change=${(event) => this.handleCmdCreateWorkTaskDueDateChange(event)} /></label><label class="block">${msg['task.progress']}<textarea class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdCreateWorkTaskProgressUpdate} @change=${(event) => this.handleCmdCreateWorkTaskProgressUpdateChange(event)}></textarea></label><button type="button" class="rounded-lg bg-[var(--button-primary-bg,#2563eb)] px-4 py-2 text-[var(--button-primary-text,#ffffff)] disabled:opacity-50" ?disabled=${busy || !this.cmdCreateWorkTaskProjectProjectId || !this.cmdCreateWorkTaskDescription || !this.cmdCreateWorkTaskDueDate} @click=${(event) => this.handleCmdCreateWorkTaskClick(event)}>${busy ? msg['status.loading'] : msg['task.create']}</button>${this.cmdCreateWorkTaskState === 'success' ? html `<p class="text-[var(--status-success-text,#166534)]">${msg['create.success']}</p>` : this.cmdCreateWorkTaskState === 'error' ? html `<p class="text-[var(--status-error-text,#b91c1c)]">${this.cmdCreateWorkTaskError || msg['create.error']}</p>` : nothing}</section>`;
    }
    renderHandoff() {
        const msg = this.msg;
        const busy = this.cmdHandoffWorkTaskToFieldWorkerState === 'loading';
        const workers = this.qryLocateFieldWorkerData;
        const output = this.cmdCreateWorkTaskOutput;
        const created = output !== null;
        return html `<section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-alt-bg,#f8fafc)] p-5 space-y-4"><h2 class="text-xl font-bold">${msg['handoff.form']}</h2><p class="text-sm text-[var(--text-muted,#64748b)]">${created ? msg['created'] : msg['not.created']}</p><h3 class="font-semibold">${msg['workers.list']}</h3>${this.qryLocateFieldWorkerState === 'loading' ? html `<p>${msg['loading']}</p>` : workers.length === 0 ? html `<p>${msg['workers.empty']}</p>` : html `<ul class="space-y-2">${workers.map((worker) => html `<li class="rounded border bg-[var(--surface-bg,#ffffff)] p-3">${msg['worker.id']}: ${String(worker['platformUserId'] ?? '')}</li>`)}</ul>`}<label class="block">${msg['handoff.description']} <span aria-label=${msg['required']}>*</span><textarea required class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdHandoffWorkTaskToFieldWorkerDescription} @change=${(event) => this.handleCmdHandoffWorkTaskToFieldWorkerDescriptionChange(event)}></textarea></label><label class="block">${msg['handoff.due']} <span aria-label=${msg['required']}>*</span><input required type="date" class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdHandoffWorkTaskToFieldWorkerDueDate} @change=${(event) => this.handleCmdHandoffWorkTaskToFieldWorkerDueDateChange(event)} /></label><label class="block">${msg['handoff.progress']}<textarea class="mt-1 w-full rounded border bg-[var(--input-bg,#ffffff)] p-2" .value=${this.cmdHandoffWorkTaskToFieldWorkerProgressUpdate} @change=${(event) => this.handleCmdHandoffWorkTaskToFieldWorkerProgressUpdateChange(event)}></textarea></label><button type="button" class="rounded-lg bg-[var(--button-secondary-bg,#e2e8f0)] px-4 py-2 text-[var(--button-secondary-text,#0f172a)] disabled:opacity-50" ?disabled=${busy || !created || !this.cmdHandoffWorkTaskToFieldWorkerWorkTaskWorkTaskId || !this.cmdHandoffWorkTaskToFieldWorkerDescription || !this.cmdHandoffWorkTaskToFieldWorkerDueDate} @click=${(event) => this.handleCmdHandoffWorkTaskToFieldWorkerClick(event)}>${busy ? msg['status.loading'] : msg['handoff.action']}</button>${this.cmdHandoffWorkTaskToFieldWorkerState === 'success' ? html `<p class="text-[var(--status-success-text,#166534)]">${msg['handoff.success']}</p>` : this.cmdHandoffWorkTaskToFieldWorkerState === 'error' ? html `<p class="text-[var(--status-error-text,#b91c1c)]">${this.cmdHandoffWorkTaskToFieldWorkerError || msg['handoff.error']}</p>` : nothing}</section>`;
    }
};
_BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgLang = new WeakMap();
_BuildFlowFsmDesktopPage21AssignWorkTaskPage_msgCache = new WeakMap();
BuildFlowFsmDesktopPage21AssignWorkTaskPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page21--assign-work-task-102046')
], BuildFlowFsmDesktopPage21AssignWorkTaskPage);
export { BuildFlowFsmDesktopPage21AssignWorkTaskPage };
